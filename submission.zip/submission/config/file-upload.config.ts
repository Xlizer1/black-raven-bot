import { MulterOptions } from '@nestjs/platform-express/multer/interfaces/multer-options.interface';
import { InvalidFileTypeException } from '../core/domain/exceptions/ProjectSubmissionError';

export const FILE_UPLOAD_CONFIG = {
  MAX_FILES: 10,
  MAX_FILE_SIZE: 5 * 1024 * 1024, // 5MB
  FIELD_NAME: 'files',
  ALLOWED_MIME_TYPES: [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'image/jpeg',
    'image/png',
  ],
};

export const multerOptions: MulterOptions = {
  limits: {
    fileSize: FILE_UPLOAD_CONFIG.MAX_FILE_SIZE,
    files: FILE_UPLOAD_CONFIG.MAX_FILES,
  },
  fileFilter: (req, file, callback) => {
    if (!FILE_UPLOAD_CONFIG.ALLOWED_MIME_TYPES.includes(file.mimetype)) {
      return callback(new InvalidFileTypeException(file.mimetype), false);
    }
    callback(null, true);
  },
};
