import { Injectable } from '@nestjs/common';
import { IncubatorRoleUpdateFailedException } from '../../domain/exceptions/ProjectSubmissionError';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { GetIncubatorRoleQuery } from '../queries/GetIncubatorRoleQuery';

@Injectable()
export class GetIncubatorRoleUseCase {
  constructor(private readonly getIncubatorRoleQuery: GetIncubatorRoleQuery) {}

  async execute(submissionId: number): Promise<ProjectResponseDto> {
    const result = await this.getIncubatorRoleQuery.execute(submissionId);
    if (!result) {
      throw new IncubatorRoleUpdateFailedException();
    }
    return result;
  }
}
