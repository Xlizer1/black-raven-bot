import { Injectable } from '@nestjs/common';
import { IncubatorRoleUpdateFailedException } from '../../domain/exceptions/ProjectSubmissionError';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { GetSubmissionIdFilesQuery } from '../queries/GetSubmissionIdFilesQuery';

@Injectable()
export class GetSubmissionIdFilesUseCase {
  constructor(private readonly getSubmissionIdFilesQuery: GetSubmissionIdFilesQuery) {}

  async execute(submissionId: number): Promise<ProjectResponseDto> {
    const result = await this.getSubmissionIdFilesQuery.execute(submissionId);
    if (!result) {
      throw new IncubatorRoleUpdateFailedException();
    }
    return result;
  }
}
