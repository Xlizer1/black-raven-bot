import { Injectable } from '@nestjs/common';
import { ProjectSubmissionEntity } from '../../domain/entities/ProjectSubmissionEntity';
import { IncubatorRoleUpdateFailedException } from '../../domain/exceptions/ProjectSubmissionError';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { GetIdeaQuery } from '../queries/GetIdeaQuery';

@Injectable()
export class GetIdeaUseCase {
  constructor(private readonly getIdeaQuery: GetIdeaQuery) {}

  async execute(submissionId: number): Promise<ProjectResponseDto> {
    const result = await this.getIdeaQuery.execute(submissionId);
    if (!result) {
      throw new IncubatorRoleUpdateFailedException();
    }
    return result;
  }
}
