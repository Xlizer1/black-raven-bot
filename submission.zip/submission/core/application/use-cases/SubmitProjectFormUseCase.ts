import { Injectable } from '@nestjs/common';
import { SubmitProjectFormCommand } from '../commands/SubmitProjectFormCommand';

@Injectable()
export class SubmitProjectFormUseCase {
  constructor(private readonly submitProjectFormCommand: SubmitProjectFormCommand) {}

  async execute(userId: number, submissionId: number): Promise<void> {
    await this.submitProjectFormCommand.execute(userId, submissionId);
  }
}
