import { Injectable } from '@nestjs/common';
import { IncubatorRoleUpdateFailedException } from '../../domain/exceptions/ProjectSubmissionError';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { GetProjectWorkQuery } from '../queries/GetProjectWorkQuery';

@Injectable()
export class GetProjectWorkUseCase {
  constructor(private readonly getProjectWorkQuery: GetProjectWorkQuery) {}

  async execute(submissionId: number): Promise<ProjectResponseDto> {
    const result = await this.getProjectWorkQuery.execute(submissionId);
    if (!result) {
      throw new IncubatorRoleUpdateFailedException();
    }
    return result;
  }
}
