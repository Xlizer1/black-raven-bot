import { Injectable } from '@nestjs/common';
import { ProjectSubmissionEntity } from '../../domain/entities/ProjectSubmissionEntity';
import { FieldOtherRequiredException, ProjectInitiationFailedException } from '../../domain/exceptions/ProjectSubmissionError';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { UpdateIdeaCommand } from '../commands/UpdateIdeaCommand';
import { InitiateProjectDto } from '../../../dto/InitiateProjectDto';
import { InitiateProjectMapper } from '../../domain/mappers/InitiateProjectMapper';
import { ServiceField } from '../../../dto/enums/ServiceField.enum';

@Injectable()
export class UpdateIdeaUseCase {
  constructor(private readonly updateIdeaCommand: UpdateIdeaCommand) {}

  async execute(userId: number, data: InitiateProjectDto): Promise<ProjectResponseDto> {
    if (data.field_of_work.includes(ServiceField.OTHER) && (!data.field_other || !data.field_other.length)) {
      throw new FieldOtherRequiredException();
    }

    const idea: ProjectSubmissionEntity = InitiateProjectMapper.toEntity(data);
    const result: ProjectSubmissionEntity = await this.updateIdeaCommand.execute(userId, idea);
    if (!result) {
      throw new ProjectInitiationFailedException();
    }
    return InitiateProjectMapper.toResponse(result);
  }
}
