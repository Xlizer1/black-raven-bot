import { Injectable } from '@nestjs/common';
import { IncubatorRoleDto } from '../../../dto/IncubatorRoleDto';
import { ProjectSubmissionEntity } from '../../domain/entities/ProjectSubmissionEntity';
import { IncubatorRoleUpdateFailedException } from '../../domain/exceptions/ProjectSubmissionError';
import { IncubatorRoleMapper } from '../../domain/mappers/IncubatorRoleMapper';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { UpdateIncubatorRoleCommand } from '../commands/UpdateIncubatorRoleCommand';

@Injectable()
export class UpdateIncubatorRoleUseCase {
  constructor(private readonly updateIncubatorRoleCommand: UpdateIncubatorRoleCommand) {}

  async execute(userId: number, data: IncubatorRoleDto): Promise<ProjectResponseDto> {
    const incubatorRole: ProjectSubmissionEntity = IncubatorRoleMapper.toEntity(data);
    const result: ProjectSubmissionEntity = await this.updateIncubatorRoleCommand.execute(userId, incubatorRole);
    
    if (!result) {
      throw new IncubatorRoleUpdateFailedException();
    }

    return IncubatorRoleMapper.toResponse(result);
  }
}