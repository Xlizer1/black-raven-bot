import { Injectable } from '@nestjs/common';
import { IncubatorRoleUpdateFailedException } from '../../domain/exceptions/ProjectSubmissionError';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { GetInfoQuery } from '../queries/GetInfoQuery';

@Injectable()
export class GetInfoUseCase {
  constructor(private readonly getInfoQuery: GetInfoQuery) {}

  async execute(submissionId: number): Promise<ProjectResponseDto> {
    const result = await this.getInfoQuery.execute(submissionId);
    if (!result) {
      throw new IncubatorRoleUpdateFailedException();
    }
    return result;
  }
}
