import { Injectable } from '@nestjs/common';
import { MarketDto } from '../../../dto/MarketDto';
import { ProjectSubmissionEntity } from '../../domain/entities/ProjectSubmissionEntity';
import { MarketInfoUpdateFailedException } from '../../domain/exceptions/ProjectSubmissionError';
import { MarketMapper } from '../../domain/mappers/MarketMapper';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { AddMarketInfoCommand } from '../commands/AddMarketInfoCommand';

@Injectable()
export class MarketUseCase {
  constructor(private readonly addMarketInfoCommand: AddMarketInfoCommand) {}

  async execute(userId: number, data: MarketDto): Promise<ProjectResponseDto> {
    const marketData = MarketMapper.toEntity(data);
    const result: ProjectSubmissionEntity =
      await this.addMarketInfoCommand.execute(userId, marketData);

    if (!result) {
      throw new MarketInfoUpdateFailedException();
    }

    return MarketMapper.toResponse(result);
  }
} 