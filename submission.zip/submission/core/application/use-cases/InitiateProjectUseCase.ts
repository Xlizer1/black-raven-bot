import { Injectable } from '@nestjs/common';
import { InitiateProjectDto } from '../../../dto/InitiateProjectDto';
import { ProjectSubmissionEntity } from '../../domain/entities/ProjectSubmissionEntity';
import { ProjectMapper } from '../../domain/mappers/ProjectMapper';
import { FieldOtherRequiredException, ProjectInitiationFailedException } from '../../domain/exceptions/ProjectSubmissionError';
import { ServiceField } from 'src/features/project/submission/dto/enums/ServiceField.enum';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { InitiateProjectCommand } from '../commands/InitiateProjectCommand';
import { InitiateProjectMapper } from '../../domain/mappers/InitiateProjectMapper';

@Injectable()
export class InitiateProjectUseCase {
  constructor(private readonly initiateProjectCommand: InitiateProjectCommand) {}

  async execute(userId: number, data: InitiateProjectDto): Promise<ProjectResponseDto> {
    // Validate fieldOther is provided when fieldOfWork is OTHER
    if (data.field_of_work.includes(ServiceField.OTHER) && !data.field_other && !data.field_other.length) {
      throw new FieldOtherRequiredException();
    }

    const ideaData = InitiateProjectMapper.toEntity(data);

    const result: ProjectSubmissionEntity =
      await this.initiateProjectCommand.execute(userId, ideaData);

    if (!result) {
      throw new ProjectInitiationFailedException();
    }

    return ProjectMapper.toResponse(result);
  }
}
