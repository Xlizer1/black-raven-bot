import { Injectable } from '@nestjs/common';
import { IncubatorRoleUpdateFailedException } from '../../domain/exceptions/ProjectSubmissionError';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { GetMarketQuery } from '../queries/GetMarketQuery';

@Injectable()
export class GetMarketUseCase {
  constructor(private readonly getMarketQuery: GetMarketQuery) {}

  async execute(submissionId: number): Promise<ProjectResponseDto> {
    const result = await this.getMarketQuery.execute(submissionId);
    if (!result) {
      throw new IncubatorRoleUpdateFailedException();
    }
    return result;
  }
}
