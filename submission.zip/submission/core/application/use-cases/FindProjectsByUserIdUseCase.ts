import { Injectable } from '@nestjs/common';
import { FindAllDto } from 'src/shared/dto/FindAllDto';
import { FindProjectsByUserIdQuery } from '../queries/FindProjectsByUserIdQuery';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { Pagination } from 'src/shared/services/ApiHelperService';
import { ProjectMapper } from '../../domain/mappers/ProjectMapper';

@Injectable()
export class FindProjectsByUserIdUseCase {
  constructor(
    private readonly findProjectsByUserIdQuery: FindProjectsByUserIdQuery
  ) {}

  async execute(
    userId: number,
    queryParams: FindAllDto,
  ): Promise<{ pagination: Pagination; data: ProjectResponseDto[] }> {
    const page = queryParams.page || 1;
    const pageSize = queryParams.pageSize || 10;
    const offset = (page - 1) * pageSize;
    const result = await this.findProjectsByUserIdQuery.execute(
      userId,
      queryParams.searchBy,
      queryParams.searchValue,
      queryParams.filterBy,
      queryParams.filterValue,
      offset,
      pageSize,
      page,
    );

    const data:ProjectResponseDto[] = result.data.map(ProjectMapper.toResponse);
    
    return {
      pagination: result.pagination,
      data: data,
    };
  }
}
