import { Injectable } from '@nestjs/common';
import { TimelineFinanceDto } from '../../../dto/TimelineFinanceDto';
import { ProjectSubmissionEntity } from '../../domain/entities/ProjectSubmissionEntity';
import { TimelineFinanceUpdateFailedException } from '../../domain/exceptions/ProjectSubmissionError';
import { TimelineFinanceMapper } from '../../domain/mappers/TimelineFinanceMapper';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { AddTimelineFinanceCommand } from '../commands/AddTimelineFinanceCommand';

@Injectable()
export class TimelineFinanceUseCase {
  constructor(private readonly addTimelineFinanceCommand: AddTimelineFinanceCommand) {}

  async execute(userId: number, data: TimelineFinanceDto): Promise<ProjectResponseDto> {
    const timelineFinanceData = TimelineFinanceMapper.toEntity(data);
    const result: ProjectSubmissionEntity =
      await this.addTimelineFinanceCommand.execute(userId, timelineFinanceData);

    if (!result) {
      throw new TimelineFinanceUpdateFailedException();
    }

    return TimelineFinanceMapper.toResponse(result);
  }
} 