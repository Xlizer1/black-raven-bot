import { Injectable } from '@nestjs/common';
import { TimelineFinanceDto } from '../../../dto/TimelineFinanceDto';
import { ProjectSubmissionEntity } from '../../domain/entities/ProjectSubmissionEntity';
import { TimelineFinanceUpdateFailedException } from '../../domain/exceptions/ProjectSubmissionError';
import { TimelineFinanceMapper } from '../../domain/mappers/TimelineFinanceMapper';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { UpdateTimelineFinanceCommand } from '../commands/UpdateTimelineFinanceCommand';

@Injectable()
export class UpdateTimelineFinanceUseCase {
  constructor(private readonly updateTimelineFinanceCommand: UpdateTimelineFinanceCommand) {}

  async execute(userId: number, data: TimelineFinanceDto): Promise<ProjectResponseDto> {
    const timelineFinance: ProjectSubmissionEntity = TimelineFinanceMapper.toEntity(data);
    const result: ProjectSubmissionEntity = await this.updateTimelineFinanceCommand.execute(userId, timelineFinance);
    
    if (!result) {
      throw new TimelineFinanceUpdateFailedException();
    }

    return TimelineFinanceMapper.toResponse(result);
  }
}