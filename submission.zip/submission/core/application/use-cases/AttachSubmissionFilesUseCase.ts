import { Injectable } from '@nestjs/common';
import { StorageProvider } from 'src/infrastructure/external-services/file-upload/strategies/StorageStrategy';
import { SubmissionFileResponseDto } from '../../../dto/SubmissionFileResponseDto';
import { SubmissionFileMapper } from '../../domain/mappers/SubmissionFileMapper';
import { AttachSubmissionFilesCommand } from '../commands/AttachSubmissionFilesCommand';

@Injectable()
export class AttachSubmissionFilesUseCase {
  constructor(
    private readonly attachSubmissionFilesCommand: AttachSubmissionFilesCommand,
  ) {}

  async execute(
    userId: number,
    submissionId: number,
    files: Express.Multer.File[],
    storageProvider: StorageProvider = StorageProvider.LOCAL
  ): Promise<SubmissionFileResponseDto[]> {
    const savedFiles = await this.attachSubmissionFilesCommand.execute(
      userId,
      submissionId,
      files,
      storageProvider
    );

    return savedFiles.map(SubmissionFileMapper.toResponse);
  }
}
