import { Injectable } from '@nestjs/common';
import { ProductInfoDto } from '../../../dto/ProductInfoDto';
import { ProjectSubmissionEntity } from '../../domain/entities/ProjectSubmissionEntity';
import { ProductInfoUpdateFailedException } from '../../domain/exceptions/ProjectSubmissionError';
import { ProductInfoMapper } from '../../domain/mappers/ProductInfoMapper';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { UpdateProductInfoCommand } from '../commands/UpdateProductInfoCommand';

@Injectable()
export class UpdateProductInfoUseCase {
  constructor(private readonly updateProductInfoCommand: UpdateProductInfoCommand) {}

  async execute(userId: number, data: ProductInfoDto): Promise<ProjectResponseDto> {
    const productInfo: ProjectSubmissionEntity = ProductInfoMapper.toEntity(data);
    const result: ProjectSubmissionEntity = await this.updateProductInfoCommand.execute(userId, productInfo);
    
    if (!result) {
      throw new ProductInfoUpdateFailedException();
    }

    return ProductInfoMapper.toResponse(result);
  }
}