import { Injectable } from '@nestjs/common';
import { ProductInfoDto } from '../../../dto/ProductInfoDto';
import { ProjectSubmissionEntity } from '../../domain/entities/ProjectSubmissionEntity';
import { ProductInfoUpdateFailedException } from '../../domain/exceptions/ProjectSubmissionError';
import { ProductInfoMapper } from '../../domain/mappers/ProductInfoMapper';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { AddProductInfoCommand } from '../commands/AddProductInfoCommand';
import { ProjectMapper } from '../../domain/mappers/ProjectMapper';

@Injectable()
export class ProductInfoUseCase {
  constructor(private readonly addProductInfoCommand: AddProductInfoCommand) {}

  async execute(userId: number, data: ProductInfoDto): Promise<ProjectResponseDto> {
    const productInfoData = ProjectMapper.toEntity(data);
    const result: ProjectSubmissionEntity =
      await this.addProductInfoCommand.execute(userId, productInfoData);

    if (!result) {
      throw new ProductInfoUpdateFailedException();
    }

    return ProductInfoMapper.toResponse(result);
  }
}
