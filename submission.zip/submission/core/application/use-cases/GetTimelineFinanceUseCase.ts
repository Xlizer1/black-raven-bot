import { Injectable } from '@nestjs/common';
import { ProjectSubmissionEntity } from '../../domain/entities/ProjectSubmissionEntity';
import { IncubatorRoleUpdateFailedException } from '../../domain/exceptions/ProjectSubmissionError';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { GetTimelineFinanceQuery } from '../queries/GetTimelineFinanceQuery';

@Injectable()
export class GetTimelineFinanceUseCase {
  constructor(private readonly getTimelineFinanceQuery: GetTimelineFinanceQuery) {}

  async execute(submissionId: number): Promise<ProjectResponseDto> {
    const result = await this.getTimelineFinanceQuery.execute(submissionId);
    if (!result) {
      throw new IncubatorRoleUpdateFailedException();
    }
    return result;
  }
}
