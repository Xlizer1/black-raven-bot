import { Injectable } from '@nestjs/common';
import { IncubatorRoleDto } from '../../../dto/IncubatorRoleDto';
import { ProjectSubmissionEntity } from '../../domain/entities/ProjectSubmissionEntity';
import { IncubatorRoleUpdateFailedException } from '../../domain/exceptions/ProjectSubmissionError';
import { IncubatorRoleMapper } from '../../domain/mappers/IncubatorRoleMapper';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { AddIncubatorRoleCommand } from '../commands/AddIncubatorRoleCommand';

@Injectable()
export class IncubatorRoleUseCase {
  constructor(private readonly addIncubatorRoleCommand: AddIncubatorRoleCommand) {}

  async execute(userId: number, data: IncubatorRoleDto): Promise<ProjectResponseDto> {
    const incubatorRole = IncubatorRoleMapper.toEntity(data);
    const result: ProjectSubmissionEntity =
      await this.addIncubatorRoleCommand.execute(userId, incubatorRole);

    if (!result) {
      throw new IncubatorRoleUpdateFailedException();
    }

    return IncubatorRoleMapper.toResponse(result);
  }
} 