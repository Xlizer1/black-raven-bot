import { Injectable } from '@nestjs/common';
import { ProjectWorkDto } from '../../../dto/ProjectWorkDto';
import { ProjectSubmissionEntity } from '../../domain/entities/ProjectSubmissionEntity';
import { ProjectWorkUpdateFailedException } from '../../domain/exceptions/ProjectSubmissionError';
import { ProjectWorkMapper } from '../../domain/mappers/ProjectWorkMapper';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { UpdateProjectWorkCommand } from '../commands/UpdateProjectWorkCommand';

@Injectable()
export class UpdateProjectWorkUseCase {
  constructor(private readonly updateProjectWorkCommand: UpdateProjectWorkCommand) {}

  async execute(userId: number, data: ProjectWorkDto): Promise<ProjectResponseDto> {
    const projectWork: ProjectSubmissionEntity = ProjectWorkMapper.toEntity(data);
    const result: ProjectSubmissionEntity = await this.updateProjectWorkCommand.execute(userId, projectWork);
    
    if (!result) {
      throw new ProjectWorkUpdateFailedException();
    }

    return ProjectWorkMapper.toResponse(result);
  }
}