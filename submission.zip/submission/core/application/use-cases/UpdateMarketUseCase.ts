import { Injectable } from '@nestjs/common';
import { MarketDto } from '../../../dto/MarketDto';
import { ProjectSubmissionEntity } from '../../domain/entities/ProjectSubmissionEntity';
import { MarketInfoUpdateFailedException } from '../../domain/exceptions/ProjectSubmissionError';
import { MarketMapper } from '../../domain/mappers/MarketMapper';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { UpdateMarketCommand } from '../commands/UpdateMarketCommand';

@Injectable()
export class UpdateMarketUseCase {
  constructor(private readonly updateMarketCommand: UpdateMarketCommand) {}

  async execute(userId: number, data: MarketDto): Promise<ProjectResponseDto> {
    const market: ProjectSubmissionEntity = MarketMapper.toEntity(data);
    const result: ProjectSubmissionEntity = await this.updateMarketCommand.execute(userId, market);
    
    if (!result) {
      throw new MarketInfoUpdateFailedException();
    }

    return MarketMapper.toResponse(result);
  }
}