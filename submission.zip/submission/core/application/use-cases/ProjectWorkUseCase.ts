import { Injectable } from '@nestjs/common';
import { ProjectWorkDto } from '../../../dto/ProjectWorkDto';
import { ProjectSubmissionEntity } from '../../domain/entities/ProjectSubmissionEntity';
import { ProjectWorkUpdateFailedException } from '../../domain/exceptions/ProjectSubmissionError';
import { ProjectWorkMapper } from '../../domain/mappers/ProjectWorkMapper';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { AddProjectWorkCommand } from '../commands/AddProjectWorkCommand';

@Injectable()
export class ProjectWorkUseCase {
  constructor(private readonly addProjectWorkCommand: AddProjectWorkCommand) {}

  async execute(userId: number, data: ProjectWorkDto): Promise<ProjectResponseDto> {
    const projectWorkData = ProjectWorkMapper.toEntity(data);
    const result: ProjectSubmissionEntity =
      await this.addProjectWorkCommand.execute(userId, projectWorkData);

    if (!result) {
      throw new ProjectWorkUpdateFailedException();
    }

    return ProjectWorkMapper.toResponse(result);
  }
} 