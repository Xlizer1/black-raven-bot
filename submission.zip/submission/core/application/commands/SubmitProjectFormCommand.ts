import { Inject, Injectable } from '@nestjs/common';
import { IProjectSubmissionRepository } from '../../domain/interfaces/IProjectSubmissionRepository';

@Injectable()
export class SubmitProjectFormCommand {
  constructor(
    @Inject('IProjectSubmissionRepository')
    private readonly projectRepository: IProjectSubmissionRepository,
  ) {}

  async execute(userId: number, submissionId: number): Promise<void> {
    await this.projectRepository.submitProjectForm(userId, submissionId);
  }
} 