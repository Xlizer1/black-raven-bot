import { Inject, Injectable } from '@nestjs/common';
import { ISubmissionFileRepository } from '../../domain/interfaces/ISubmissionFileRepository';
import { FileUploadService } from 'src/infrastructure/external-services/file-upload/FileUploadService';
import { StorageProvider } from 'src/infrastructure/external-services/file-upload/strategies/StorageStrategy';
import { v4 as uuidv4 } from 'uuid';
import * as path from 'path';
import { 
  FileUploadFailedException,
  FileStorageFailedException,
  FileCleanupFailedException,
  NoFilesProvidedException
} from '../../domain/exceptions/ProjectSubmissionError';

@Injectable()
export class AttachSubmissionFilesCommand {
  constructor(
    private readonly fileUploadService: FileUploadService,
    @Inject('ISubmissionFileRepository')
    private readonly submissionFileRepository: ISubmissionFileRepository,
  ) {}

  async execute(
    userId: number,
    submissionId: number,
    files: Express.Multer.File[],
    storageProvider: StorageProvider = StorageProvider.LOCAL
  ): Promise<any[]> {
    if (!files || files.length === 0) {
      throw new NoFilesProvidedException();
    }

    // Prepare file metadata first
    const fileMetadata = files.map(file => {
      const ext = path.extname(file.originalname);
      const uniqueFileName = `${uuidv4()}${ext}`;
      const relativePath = `project-submissions/${submissionId}/${uniqueFileName}`;
      
      return {
        fileName: file.originalname,
        fileUrl: `/uploads/${relativePath}`,
        fileType: file.mimetype,
        filePath: relativePath
      };
    });

    let savedFiles: any[];

    try {
      // Save metadata to database first
      savedFiles = await this.submissionFileRepository.attachFiles(
        userId,
        submissionId,
        fileMetadata,
      );

      // Try to upload all files
      try {
        const uploadPromises = files.map((file, index) =>
          this.fileUploadService.uploadFile(
            file,
            fileMetadata[index].filePath,
            storageProvider
          ),
        );

        await Promise.all(uploadPromises);
      } catch (uploadError) {
        // If file upload fails, delete the database records
        if (savedFiles && savedFiles.length > 0) {
          try {
            await Promise.all(
              savedFiles.map(file => 
                this.submissionFileRepository.deleteFile(userId, file.submission_file_id)
              )
            );
          } catch (cleanupError) {
            throw new FileCleanupFailedException(cleanupError.message);
          }
        }
        throw new FileStorageFailedException(uploadError.message);
      }

      return savedFiles;
    } catch (error) {
      if (error instanceof Error) {
        throw new FileUploadFailedException(error.message);
      }
      throw error;
    }
  }
} 