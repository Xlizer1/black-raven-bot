import { Inject, Injectable } from '@nestjs/common';
import { IProjectSubmissionRepository } from '../../domain/interfaces/IProjectSubmissionRepository';
import { ProjectSubmissionEntity } from '../../domain/entities/ProjectSubmissionEntity';

@Injectable()
export class AddMarketInfoCommand {
  constructor(
    @Inject('IProjectSubmissionRepository')
    private readonly projectRepository: IProjectSubmissionRepository,
  ) {}

  async execute(userId: number, data: ProjectSubmissionEntity): Promise<ProjectSubmissionEntity | null> {
    return this.projectRepository.addMarketInfo(userId, data);
  }
} 