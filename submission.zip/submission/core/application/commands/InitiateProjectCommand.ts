import { Inject, Injectable } from '@nestjs/common';
import { IProjectSubmissionRepository } from '../../domain/interfaces/IProjectSubmissionRepository';
import { ProjectSubmissionEntity } from '../../domain/entities/ProjectSubmissionEntity';
import { IProjectInitiation } from '../../domain/interfaces/IProjectInitiation';

@Injectable()
export class InitiateProjectCommand {
  constructor(
    @Inject('IProjectSubmissionRepository')
    private readonly projectRepository: IProjectSubmissionRepository,
  ) {}

  async execute(userId: number, ideaData: ProjectSubmissionEntity): Promise<ProjectSubmissionEntity | null> {
    return this.projectRepository.initiateProject(userId, ideaData);
  }
} 