import { Inject, Injectable } from "@nestjs/common";
import { IProjectSubmissionRepository } from "../../domain/interfaces/IProjectSubmissionRepository";
import { ProjectSubmissionEntity } from "../../domain/entities/ProjectSubmissionEntity";

@Injectable()
export class CreateProjectSubmissionCommand {
    constructor(
        @Inject("IProjectSubmissionRepository")
        private readonly projectRepository: IProjectSubmissionRepository
    ){}
    async execute(userId: number, data: ProjectSubmissionEntity){
        const result = this.projectRepository.initiateProject(userId, data)
        return result
    }
}