import { Inject, Injectable } from '@nestjs/common';
import { IProjectSubmissionRepository } from '../../domain/interfaces/IProjectSubmissionRepository';

@Injectable()
export class GetTimelineFinanceQuery {
  constructor(
    @Inject('IProjectSubmissionRepository')
    private readonly projectRepository: IProjectSubmissionRepository,
  ) {}

  async execute(submissionId: number): Promise<any> {
    return await this.projectRepository.getTimelineFinance(submissionId);
  }
}
