import { Inject, Injectable } from '@nestjs/common';
import { IProjectSubmissionRepository } from '../../domain/interfaces/IProjectSubmissionRepository';
import { Pagination } from 'src/shared/services/ApiHelperService';
import { ProjectSubmissionEntity } from '../../domain/entities/ProjectSubmissionEntity';

@Injectable()
export class FindProjectsByUserIdQuery {
  constructor(
    @Inject('IProjectSubmissionRepository')
    private readonly projectRepository: IProjectSubmissionRepository,
  ) {}

  async execute(
    userId: number,
    searchBy: string,
    searchValue: string,
    filterBy: string,
    filterValue: string,
    offset: number,
    pageSize: number,
    currentPage: number,
  ): Promise<{ pagination: Pagination; data: ProjectSubmissionEntity[] }> {
    const result = await this.projectRepository.findByUserId(
      userId,
      searchBy,
      searchValue,
      filterBy,
      filterValue,
      offset,
      pageSize,
      currentPage,
    );
    return result;
  }
}
