import { ProductInfoDto } from '../../../dto/ProductInfoDto';
import { ProjectSubmissionEntity } from '../entities/ProjectSubmissionEntity';

export class ProductInfoMapper {
  static toEntity(row: any): ProjectSubmissionEntity {
    return new ProjectSubmissionEntity({
      submissionId: row.submission_id,
      mainProduct: row.main_product,
      similarProducts: row.similar_products,
      productNeed: row.product_need,
      targetCustomers: row.target_customers,
      updateStages: row.update_stages,
      sellingMethod: row.selling_method,
      innovation: row.innovation,
    });
  }
  
  static fromDatabase(row: any): ProjectSubmissionEntity {
    return new ProjectSubmissionEntity({
      submissionId: row.submission_id,
      userId: row.user_id,
      status: row.status,
      formVersion: row.form_version,
      feedback: row.feedback,
      submissionDate: row.submission_date,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
      projectIdea: row.project_idea,
      projectStage: row.project_stage,
      fieldOfWork: row.field_of_work || [],
      fieldOther: row.field_other,
      projectStrengths: row.project_strengths,
      mainProduct: row.main_product,
      similarProducts: row.similar_products,
      productNeed: row.product_need,
      targetCustomers: row.target_customers,
      updateStages: row.update_stages,
      sellingMethod: row.selling_method,
      innovation: row.innovation,
    });
  }

  static fromInitiateProductInfoDtoDto(dto: ProductInfoDto): ProjectSubmissionEntity{
    const entity = new ProjectSubmissionEntity();
    entity.submissionId = dto.submission_id;
    entity.mainProduct = dto.main_product;
    entity.similarProducts = dto.similar_products || null;
    entity.productNeed = dto.product_need;
    entity.targetCustomers = dto.target_customers;
    entity.updateStages = dto.update_stages || null;
    entity.sellingMethod = dto.selling_method;
    entity.innovation = dto.innovation;
    return entity;
  }

  static toResponse(entity: ProjectSubmissionEntity): any {
    return {
      submission_id: entity.submissionId,
      user_id: entity.userId,
      status: entity.status,
      form_version: entity.formVersion,
      feedback: entity.feedback,
      submission_date: entity.submissionDate,
      created_at: entity.createdAt,
      updated_at: entity.updatedAt,
      project_idea: entity.projectIdea,
      project_stage: entity.projectStage,
      field_of_work: entity.fieldOfWork,
      field_other: entity.fieldOther,
      project_strengths: entity.projectStrengths,
      main_product: entity.mainProduct,
      similar_products: entity.similarProducts,
      product_need: entity.productNeed,
      target_customers: entity.targetCustomers,
      update_stages: entity.updateStages,
      selling_method: entity.sellingMethod,
      innovation: entity.innovation,
    };
  }
} 