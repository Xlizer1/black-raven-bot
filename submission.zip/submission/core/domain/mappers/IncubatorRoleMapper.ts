import { ProjectSubmissionEntity } from '../entities/ProjectSubmissionEntity';

export class IncubatorRoleMapper {

  static toEntity(row: any): ProjectSubmissionEntity {
    return new ProjectSubmissionEntity({
      submissionId: row.submission_id,
      incubatorBenefits: row.incubator_benefits,
      projectRequirements: row.project_requirements,
    });
  }

  static fromDatabase(row: any): ProjectSubmissionEntity {
    return new ProjectSubmissionEntity({
      submissionId: row.submission_id,
      userId: row.user_id,
      status: row.status,
      formVersion: row.form_version,
      feedback: row.feedback,
      submissionDate: row.submission_date,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
      // Step 1: Project Idea
      projectIdea: row.project_idea,
      projectStage: row.project_stage,
      fieldOfWork: row.field_of_work || [],
      fieldOther: row.field_other,
      projectStrengths: row.project_strengths,
      // Step 2: Product Info
      mainProduct: row.main_product,
      similarProducts: row.similar_products,
      productNeed: row.product_need,
      targetCustomers: row.target_customers,
      updateStages: row.update_stages,
      sellingMethod: row.selling_method,
      innovation: row.innovation,
      // Step 3: Market
      marketReadyDate: row.market_ready_date,
      marketNeeds: row.market_needs,
      otherProducts: row.other_products,
      marketScope: row.market_scope,
      // Step 4: Incubator Role
      incubatorBenefits: row.incubator_benefits,
      projectRequirements: row.project_requirements,
    });
  }

  static toResponse(entity: ProjectSubmissionEntity): any {
    return {
      submission_id: entity.submissionId,
      user_id: entity.userId,
      status: entity.status,
      form_version: entity.formVersion,
      feedback: entity.feedback,
      submission_date: entity.submissionDate,
      created_at: entity.createdAt,
      updated_at: entity.updatedAt,
      // Step 1: Project Idea
      project_idea: entity.projectIdea,
      project_stage: entity.projectStage,
      field_of_work: entity.fieldOfWork,
      field_other: entity.fieldOther,
      project_strengths: entity.projectStrengths,
      // Step 2: Product Info
      main_product: entity.mainProduct,
      similar_products: entity.similarProducts,
      product_need: entity.productNeed,
      target_customers: entity.targetCustomers,
      update_stages: entity.updateStages,
      selling_method: entity.sellingMethod,
      innovation: entity.innovation,
      // Step 3: Market
      market_ready_date: entity.marketReadyDate,
      market_needs: entity.marketNeeds,
      other_products: entity.otherProducts,
      market_scope: entity.marketScope,
      // Step 4: Incubator Role
      incubator_benefits: entity.incubatorBenefits,
      project_requirements: entity.projectRequirements,
    };
  }
} 