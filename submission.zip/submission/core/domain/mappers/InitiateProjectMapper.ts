import { InitiateProjectDto } from '../../../dto/InitiateProjectDto';
import { ProjectResponseDto } from '../../../dto/ProjectResponseDto';
import { ProjectSubmissionEntity } from '../entities/ProjectSubmissionEntity';

export class InitiateProjectMapper {
  static toEntity(row: InitiateProjectDto): any {
    return {
      projectIdea: row.project_idea,
      projectStage: row.project_stage,
      fieldOfWork: row.field_of_work,
      fieldOther: row.field_other,
      projectStrengths: row.project_strengths,
      submissionId: row.submission_id
    };
}

  static fromDatabase(row: any): ProjectSubmissionEntity {
    return new ProjectSubmissionEntity({
      submissionId: row.submission_id,
      userId: row.user_id,
      firstName: row.first_name,
      lastName: row.last_name,
      status: row.status,
      formVersion: row.form_version,
      feedback: row.feedback,
      submissionDate: row.submission_date,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
      projectIdea: row.project_idea,
      projectStage: row.project_stage,
      fieldOfWork: row.field_of_work || [],
      fieldOther: row.field_other,
      projectStrengths: row.project_strengths,
      mainProduct: row.main_product,
      similarProducts: row.similar_products,
      productNeed: row.product_need,
      targetCustomers: row.target_customers,
      updateStages: row.update_stages,
      sellingMethod: row.selling_method,
      innovation: row.innovation,
      marketReadyDate: row.market_ready_date,
      marketNeeds: row.market_needs,
      otherProducts: row.other_products,
      marketScope: row.market_scope,
      incubatorBenefits: row.incubator_benefits,
      projectRequirements: row.project_requirements,
      phase1Desc: row.phase_1_desc,
      phase1Duration: row.phase_1_duration,
      phase2Desc: row.phase_2_desc,
      phase2Duration: row.phase_2_duration,
      phase3Desc: row.phase_3_desc,
      phase3Duration: row.phase_3_duration,
      phase4Desc: row.phase_4_desc,
      phase4Duration: row.phase_4_duration,
      salesIncrease6mo: row.sales_increase_6mo
        ? parseInt(row.sales_increase_6mo, 10)
        : null,
      salesIncrease12mo: row.sales_increase_12mo
        ? parseInt(row.sales_increase_12mo, 10)
        : null,
      salesIncrease24mo: row.sales_increase_24mo
        ? parseInt(row.sales_increase_24mo, 10)
        : null,
      estimatedInvestmentCost: row.estimated_investment_cost
        ? parseInt(row.estimated_investment_cost, 10)
        : null,
      estimatedFundingNeeded: row.estimated_funding_needed
        ? parseInt(row.estimated_funding_needed, 10)
        : null,
      fundingSources: row.funding_sources,
      ownershipStructure: row.ownership_structure,
      dailyManagement: row.daily_management,
      employeeCount: row.employee_count
        ? parseInt(row.employee_count, 10)
        : null,
      neededSkills: row.needed_skills,
      activityNature: row.activity_nature,
    });
  }

  static toResponse(entity: ProjectSubmissionEntity): any {
    return {
      submission_id: entity.submissionId,
      user_id: entity.userId,
      first_name: entity.firstName,
      last_name: entity.lastName,
      status: entity.status,
      submission_date: entity.submissionDate,
      project_idea: entity.projectIdea,
      project_stage: entity.projectStage,
      field_of_work: entity.fieldOfWork,
      field_other: entity.fieldOther,
      project_strengths: entity.projectStrengths,
    };
  }
}
