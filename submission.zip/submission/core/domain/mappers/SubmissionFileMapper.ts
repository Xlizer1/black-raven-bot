import { SubmissionFileResponseDto } from '../../../dto/SubmissionFileResponseDto';

export class SubmissionFileMapper {
  static toResponse(data: any): SubmissionFileResponseDto {
    return {
      submission_file_id: data.submission_file_id,
      submission_id: data.submission_id,
      file_name: data.file_name,
      file_url: data.file_url,
      file_type: data.file_type,
      uploaded_at: data.uploaded_at,
    };
  }
} 