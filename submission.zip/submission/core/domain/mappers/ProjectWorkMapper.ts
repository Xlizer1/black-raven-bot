import { ProjectSubmissionEntity } from '../entities/ProjectSubmissionEntity';

export class ProjectWorkMapper {
  static toEntity(row: any): ProjectSubmissionEntity {
    return new ProjectSubmissionEntity({
      submissionId: row.submission_id,
      ownershipStructure: row.ownership_structure,
      dailyManagement: row.daily_management,
      employeeCount: row.employee_count,
      neededSkills: row.needed_skills,
      activityNature: row.activity_nature,
    });
  }

  static fromDatabase(row: any): ProjectSubmissionEntity {
    return new ProjectSubmissionEntity({
      submissionId: row.submission_id,
      userId: row.user_id,
      status: row.status,
      formVersion: row.form_version,
      feedback: row.feedback,
      submissionDate: row.submission_date,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
      // Step 1: Project Idea
      projectIdea: row.project_idea,
      projectStage: row.project_stage,
      fieldOfWork: row.field_of_work || [],
      fieldOther: row.field_other,
      projectStrengths: row.project_strengths,
      // Step 2: Product Info
      mainProduct: row.main_product,
      similarProducts: row.similar_products,
      productNeed: row.product_need,
      targetCustomers: row.target_customers,
      updateStages: row.update_stages,
      sellingMethod: row.selling_method,
      innovation: row.innovation,
      // Step 3: Market
      marketReadyDate: row.market_ready_date,
      marketNeeds: row.market_needs,
      otherProducts: row.other_products,
      marketScope: row.market_scope,
      // Step 4: Incubator Role
      incubatorBenefits: row.incubator_benefits,
      projectRequirements: row.project_requirements,
      // Step 5: Timeline & Finance
      phase1Desc: row.phase_1_desc,
      phase1Duration: row.phase_1_duration,
      phase2Desc: row.phase_2_desc,
      phase2Duration: row.phase_2_duration,
      phase3Desc: row.phase_3_desc,
      phase3Duration: row.phase_3_duration,
      phase4Desc: row.phase_4_desc,
      phase4Duration: row.phase_4_duration,
      salesIncrease6mo: row.sales_increase_6mo,
      salesIncrease12mo: row.sales_increase_12mo,
      salesIncrease24mo: row.sales_increase_24mo,
      estimatedInvestmentCost: row.estimated_investment_cost,
      estimatedFundingNeeded: row.estimated_funding_needed,
      fundingSources: row.funding_sources,
      // Step 6: Project Work
      ownershipStructure: row.ownership_structure,
      dailyManagement: row.daily_management,
      employeeCount: row.employee_count,
      neededSkills: row.needed_skills,
      activityNature: row.activity_nature,
    });
  }

  static toResponse(entity: ProjectSubmissionEntity): any {
    return {
      submission_id: entity.submissionId,
      user_id: entity.userId,
      status: entity.status,
      form_version: entity.formVersion,
      feedback: entity.feedback,
      submission_date: entity.submissionDate,
      created_at: entity.createdAt,
      updated_at: entity.updatedAt,
      // Step 1: Project Idea
      project_idea: entity.projectIdea,
      project_stage: entity.projectStage,
      field_of_work: entity.fieldOfWork,
      field_other: entity.fieldOther,
      project_strengths: entity.projectStrengths,
      // Step 2: Product Info
      main_product: entity.mainProduct,
      similar_products: entity.similarProducts,
      product_need: entity.productNeed,
      target_customers: entity.targetCustomers,
      update_stages: entity.updateStages,
      selling_method: entity.sellingMethod,
      innovation: entity.innovation,
      // Step 3: Market
      market_ready_date: entity.marketReadyDate,
      market_needs: entity.marketNeeds,
      other_products: entity.otherProducts,
      market_scope: entity.marketScope,
      // Step 4: Incubator Role
      incubator_benefits: entity.incubatorBenefits,
      project_requirements: entity.projectRequirements,
      // Step 5: Timeline & Finance
      phase_1_desc: entity.phase1Desc,
      phase_1_duration: entity.phase1Duration,
      phase_2_desc: entity.phase2Desc,
      phase_2_duration: entity.phase2Duration,
      phase_3_desc: entity.phase3Desc,
      phase_3_duration: entity.phase3Duration,
      phase_4_desc: entity.phase4Desc,
      phase_4_duration: entity.phase4Duration,
      sales_increase_6mo: entity.salesIncrease6mo,
      sales_increase_12mo: entity.salesIncrease12mo,
      sales_increase_24mo: entity.salesIncrease24mo,
      estimated_investment_cost: entity.estimatedInvestmentCost,
      estimated_funding_needed: entity.estimatedFundingNeeded,
      funding_sources: entity.fundingSources,
      // Step 6: Project Work
      ownership_structure: entity.ownershipStructure,
      daily_management: entity.dailyManagement,
      employee_count: entity.employeeCount,
      needed_skills: entity.neededSkills,
      activity_nature: entity.activityNature,
    };
  }
} 