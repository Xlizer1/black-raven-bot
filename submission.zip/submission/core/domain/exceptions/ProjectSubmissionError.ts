export class ProjectError extends Error {
  public details?: any;
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
    this.name = this.constructor.name;
    Error.captureStackTrace(this, this.constructor);
  }
}

export class FieldOtherRequiredException extends ProjectError {
  constructor() {
    super(400, 'field_other_required_when_field_is_other');
  }
}

export class ProjectInitiationFailedException extends ProjectError {
  constructor() {
    super(500, 'failed_to_initiate_project');
  }
}

export class ProductInfoUpdateFailedException extends ProjectError {
  constructor() {
    super(500, 'failed_to_update_product_info');
  }
}

export class MarketInfoUpdateFailedException extends ProjectError {
  constructor() {
    super(500, 'failed_to_update_market_info');
  }
}

export class IncubatorRoleUpdateFailedException extends ProjectError {
  constructor() {
    super(500, 'failed_to_update_incubator_role_info');
  }
}

export class TimelineFinanceUpdateFailedException extends ProjectError {
  constructor() {
    super(500, 'failed_to_update_timeline_finance_info');
  }
}

export class ProjectWorkUpdateFailedException extends ProjectError {
  constructor() {
    super(500, 'failed_to_update_project_work_info');
  }
}

export class UnauthorizedFileAccessError extends ProjectError {
  constructor() {
    super(403, 'unauthorized_file_access');
  }
}

export class FileUploadFailedException extends ProjectError {
  constructor(details?: string) {
    super(500, `failed_to_upload_files${details ? ': ' + details : ''}`);
    this.details = details;
  }
}

export class FileStorageFailedException extends ProjectError {
  constructor(details?: string) {
    super(500, `failed_to_store_files${details ? ': ' + details : ''}`);
    this.details = details;
  }
}

export class FileDeletionFailedException extends ProjectError {
  constructor(details?: string) {
    super(500, `failed_to_delete_files${details ? ': ' + details : ''}`);
    this.details = details;
  }
}

export class FileCleanupFailedException extends ProjectError {
  constructor(details?: string) {
    super(500, `failed_to_cleanup_files${details ? ': ' + details : ''}`);
    this.details = details;
  }
}

export class NoFilesProvidedException extends ProjectError {
  constructor() {
    super(400, 'no_files_provided');
  }
}

export class InvalidFileTypeException extends ProjectError {
  constructor(type: string) {
    super(400, `invalid_file_type: ${type}`);
    this.details = { type };
  }
}

export class FileSizeLimitExceededException extends ProjectError {
  constructor(size: number, limit: number) {
    super(400, 'file_size_limit_exceeded');
    this.details = { size, limit };
  }
}

export class TooManyFilesException extends ProjectError {
  constructor(count: number, limit: number) {
    super(400, 'too_many_files_provided');
    this.details = { count, limit };
  }
}

export class UnexpectedFieldException extends ProjectError {
  constructor(field: string) {
    super(400, 'unexpected_field_provided');
    this.details = { field };
  }
} 