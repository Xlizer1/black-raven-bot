import { ProjectSubmissionEntity } from '../entities/ProjectSubmissionEntity';
import { Pagination } from 'src/shared/services/ApiHelperService';

export interface IProjectSubmissionRepository {
  initiateProject(
    userId: number,
    projectInitiation: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null>;

  addProductInfo(
    userId: number,
    data: ProjectSubmissionEntity
  ): Promise<ProjectSubmissionEntity | null>;

  findByUserId(
    userId: number,
    searchBy: string,
    searchValue: string,
    filterBy: string,
    filterValue: string,
    offset: number,
    pageSize: number,
    currentPage: number,
  ): Promise<{ pagination: Pagination; data: ProjectSubmissionEntity[] }>;

  addMarketInfo(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null>;

  addIncubatorRoleInfo(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null>;

  addTimelineFinanceInfo(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null>;

  addProjectWorkInfo(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null>;

  submitProjectForm(userId: number, submissionId: number): Promise<void>;

  getIdea(submissionId: number): Promise<any>;

  getIncubatorRole(submissionId: number): Promise<any>;

  getInfo(submissionId: number): Promise<any>;

  getMarket(submissionId: number): Promise<any>;

  getProjectWork(submissionId: number): Promise<any>;

  getSubmissionIdFiles(submissionId: number): Promise<any>;

  getTimelineFinance(submissionId: number): Promise<any>;

  updateIdea(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null>;

  updateProductInfo(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null>;

  updateMarketInfo(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null>;

  updateIncubatorRoleInfo(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null>;

  updateTimelineFinanceInfo(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null>;

  updateProjectWorkInfo(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null>;
}
