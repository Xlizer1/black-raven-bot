import { StorageProvider } from 'src/infrastructure/external-services/file-upload/strategies/StorageStrategy';

export interface IFileUploadService {
  uploadFile(
    file: Express.Multer.File,
    filePath: string,
    storageProvider: StorageProvider
  ): Promise<void>;
} 