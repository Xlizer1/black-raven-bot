export interface IProjectInitiation {
  projectIdea: string;
  projectStage: string;
  fieldOfWork: string[];
  fieldOther?: string;
  projectStrengths: string;
} 