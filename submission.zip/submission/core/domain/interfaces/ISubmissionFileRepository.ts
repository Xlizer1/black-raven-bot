export interface ISubmissionFileRepository {
  attachFiles(
    userId: number,
    submissionId: number,
    fileMetadata: {
      fileName: string;
      fileUrl: string;
      fileType: string;
      filePath: string;
    }[]
  ): Promise<any[]>;

  deleteFile(userId: number, submissionFileId: number): Promise<void>;
} 