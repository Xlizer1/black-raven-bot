import { MarketScope } from '../../../dto/enums/MarketScope.enum';

export class ProjectSubmissionEntity {
  submissionId: number;
  userId: number;
  status: string;
  firstName?: string;
  lastName?: string;
  formVersion: number;
  feedback: string;
  submissionDate: Date;
  createdAt: Date;
  updatedAt: Date;
  projectIdea: string;
  projectStage: string;
  fieldOfWork: string[];
  fieldOther: string;
  projectStrengths: string;
  mainProduct: string;
  similarProducts: string;
  productNeed: string;
  targetCustomers: string;
  updateStages: string;
  sellingMethod: string;
  innovation: string;
  marketReadyDate: Date;
  expectedCustomers: string;
  marketNeeds: string;
  otherProducts: string;
  marketScope: MarketScope;
  incubatorBenefits: string;
  projectRequirements: string;
  phase1Desc: string;
  phase1Duration: string;
  phase2Desc: string;
  phase2Duration: string;
  phase3Desc: string;
  phase3Duration: string;
  phase4Desc: string;
  phase4Duration: string;
  salesIncrease6mo: number;
  salesIncrease12mo: number;
  salesIncrease24mo: number;
  estimatedInvestmentCost: number;
  estimatedFundingNeeded: number;
  fundingSources: string;
  ownershipStructure: string;
  dailyManagement: string;
  employeeCount: number;
  neededSkills: string;
  activityNature: string;

  constructor();
  constructor(data: Partial<ProjectSubmissionEntity>);
  constructor(
    submissionId: number,
    userId: number,
    status: string,
    formVersion: number,
    feedback: string,
    submissionDate: Date,
    createdAt: Date,
    updatedAt: Date,
    projectIdea: string,
    projectStage: string,
    fieldOfWork: string[],
    fieldOther: string,
    projectStrengths: string,
    mainProduct: string,
    similarProducts: string,
    productNeed: string,
    targetCustomers: string,
    updateStages: string,
    sellingMethod: string,
    innovation: string,
    marketReadyDate: Date,
    marketNeeds: string,
    otherProducts: string,
    marketScope: MarketScope,
    incubatorBenefits: string,
    projectRequirements: string,
    phase1Desc: string,
    phase1Duration: string,
    phase2Desc: string,
    phase2Duration: string,
    phase3Desc: string,
    phase3Duration: string,
    phase4Desc: string,
    phase4Duration: string,
    salesIncrease6mo: number,
    salesIncrease12mo: number,
    salesIncrease24mo: number,
    estimatedInvestmentCost: number,
    estimatedFundingNeeded: number,
    fundingSources: string,
    ownershipStructure: string,
    dailyManagement: string,
    employeeCount: number,
    neededSkills: string,
    activityNature: string,
  );

  constructor(...args: any[]) {
    if (args.length === 1 && typeof args[0] === 'object') {
      Object.assign(this, args[0]);
    } else {
      [
        this.submissionId,
        this.userId,
        this.status,
        this.formVersion,
        this.feedback,
        this.submissionDate,
        this.createdAt,
        this.updatedAt,
        this.projectIdea,
        this.projectStage,
        this.fieldOfWork,
        this.fieldOther,
        this.projectStrengths,
        this.mainProduct,
        this.similarProducts,
        this.productNeed,
        this.targetCustomers,
        this.updateStages,
        this.sellingMethod,
        this.innovation,
        this.marketReadyDate,
        this.marketNeeds,
        this.otherProducts,
        this.marketScope,
        this.incubatorBenefits,
        this.projectRequirements,
        this.phase1Desc,
        this.phase1Duration,
        this.phase2Desc,
        this.phase2Duration,
        this.phase3Desc,
        this.phase3Duration,
        this.phase4Desc,
        this.phase4Duration,
        this.salesIncrease6mo,
        this.salesIncrease12mo,
        this.salesIncrease24mo,
        this.estimatedInvestmentCost,
        this.estimatedFundingNeeded,
        this.fundingSources,
        this.ownershipStructure,
        this.dailyManagement,
        this.employeeCount,
        this.neededSkills,
        this.activityNature,
      ] = args;
    }
  }
}
