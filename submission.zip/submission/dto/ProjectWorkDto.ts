import { IsString, IsNumber } from 'class-validator';

export class ProjectWorkDto {
  @IsNumber()
  submission_id: number; // Fixed type to match @IsNumber() decorator

  @IsString()
  ownership_structure: string;

  @IsString()
  daily_management: string;

  @IsNumber()
  employee_count: number;

  @IsString()
  needed_skills: string;

  @IsString()
  activity_nature: string;
}