import { IsString, IsEnum, IsOptional, IsNumber, IsArray } from 'class-validator';
import { ServiceField } from './enums/ServiceField.enum';
import { ProjectStage } from './enums/ProjectStage.enum';

export class InitiateProjectDto {
  @IsNumber()
  @IsOptional() // Optional for create, required for update
  submission_id?: number;

  @IsString()
  project_idea: string;

  @IsEnum(ProjectStage)
  project_stage: ProjectStage;

  @IsArray()
  @IsEnum(ServiceField, { each: true })
  field_of_work: ServiceField[];

  @IsString()
  @IsOptional()
  field_other?: string;

  @IsString()
  @IsOptional()
  project_strengths?: string; // Made optional to match your decorator
}