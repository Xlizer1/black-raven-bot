export class ProjectResponseDto {
  submission_id: number;
  user_id: number;
  first_name: string;
  last_name: string;
  status: string;
  submission_date: Date | null;
  project_idea: string;
  project_stage: string;
  field_of_work: string[];
}
