import { IsString, IsOptional, IsNumber } from 'class-validator';

export class TimelineFinanceDto {
  @IsNumber()
  submission_id: number; // Fixed type to match @IsNumber() decorator

  @IsString()
  phase_1_desc: string;

  @IsString()
  phase_1_duration: string;

  @IsString()
  phase_2_desc: string;

  @IsString()
  phase_2_duration: string;

  @IsString()
  phase_3_desc: string;

  @IsString()
  phase_3_duration: string;

  @IsString()
  phase_4_desc: string;

  @IsString()
  phase_4_duration: string;

  @IsNumber()
  sales_increase_6mo: number;

  @IsNumber()
  sales_increase_12mo: number;

  @IsNumber()
  sales_increase_24mo: number;

  @IsNumber()
  estimated_investment_cost: number;

  @IsNumber()
  estimated_funding_needed: number;

  @IsString()
  funding_sources: string;
}