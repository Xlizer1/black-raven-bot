import { IsString, IsOptional, IsNumber, IsDateString, IsEnum } from 'class-validator';
import { MarketScope } from './enums/MarketScope.enum';

export class MarketDto {
  @IsNumber()
  submission_id: number; // Fixed type to match @IsNumber() decorator

  @IsDateString()
  @IsOptional()
  market_ready_date?: Date;

  @IsString()
  market_needs: string;

  @IsString()
  expected_customers: string;

  @IsString()
  @IsOptional()
  other_products?: string;

  @IsEnum(MarketScope)
  market_scope: MarketScope;
}