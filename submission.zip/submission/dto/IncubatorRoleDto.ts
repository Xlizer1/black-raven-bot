import { IsString, IsNumber } from 'class-validator';

export class IncubatorRoleDto {
  @IsNumber()
  submission_id: string; // Note: Type mismatch - should be number if using @IsNumber()
  
  @IsString()
  incubator_benefits: string;
  
  @IsString()
  project_requirements: string;
}