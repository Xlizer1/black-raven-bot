import { IsString, IsOptional, IsNumber } from 'class-validator';
/**
 * ALl Field must use Snake Case for naming
 */
export class ProductInfoDto {
  @IsNumber()
  submission_id: number;

  @IsString()
  main_product: string;

  @IsString()
  @IsOptional()
  similar_products?: string;

  @IsString()
  product_need: string;

  @IsString()
  target_customers: string;

  @IsString()
  @IsOptional()
  update_stages?: string;

  @IsString()
  selling_method: string;

  @IsString()
  innovation: string;
}