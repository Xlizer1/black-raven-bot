import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsNumber, ValidateNested, ArrayMaxSize } from 'class-validator';
import { Type } from 'class-transformer';

class UploadedFile {
  @ApiProperty({ example: 'files' })
  fieldname: string;

  @ApiProperty({ example: 'business-plan.pdf' })
  originalname: string;

  @ApiProperty({ example: '7bit' })
  encoding: string;

  @ApiProperty({ example: 'application/pdf' })
  mimetype: string;

  @ApiProperty({ example: 1024 })
  size: number;

  @ApiProperty({ example: 'buffer data' })
  buffer: Buffer;
}

export class UploadSubmissionFilesDto {
  @ApiProperty({
    description: 'The ID of the project submission to attach files to',
    example: 123
  })
  @IsNumber()
  submission_id: number;

  @ApiProperty({
    type: [UploadedFile],
    maxItems: 10,
    description: 'Array of files to upload (maximum 10 files)'
  })
  @IsArray()
  @ArrayMaxSize(10)
  @ValidateNested({ each: true })
  @Type(() => UploadedFile)
  files: UploadedFile[];
}

// Constants for file upload validation
export const FILE_UPLOAD_CONFIG = {
  MAX_FILES: 10,
  MAX_FILE_SIZE: 5 * 1024 * 1024, // 5MB
  ALLOWED_MIME_TYPES: [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'image/jpeg',
    'image/png',
    'image/gif'
  ]
}; 