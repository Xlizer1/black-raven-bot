import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsNotEmpty, ArrayNotEmpty } from 'class-validator';
import { Transform } from 'class-transformer';

export class AttachSubmissionFilesDto {
  @ApiProperty({
    type: 'array',
    items: {
      type: 'file',
      properties: {
        fieldname: { type: 'string' },
        originalname: { type: 'string' },
        encoding: { type: 'string' },
        mimetype: { type: 'string' },
        size: { type: 'number' }
      }
    }
  })
  @IsArray()
  @ArrayNotEmpty({ message: 'At least one file must be provided' })
  @IsNotEmpty({ each: true })
  @Transform(({ value }) => value || [])
  files: Express.Multer.File[];
} 