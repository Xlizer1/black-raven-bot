export enum ServiceField {
  AGRICULTURAL = 'agricultural',
  OPERATING_SYSTEMS = 'operating_systems',
  SERVICE = 'service',
  DIGITAL_CONTENT_APPLICATIONS = 'digital_content_applications',
  INDUSTRIAL = 'industrial',
  COMMUNICATIONS = 'communications',
  ELECTRONIC_SERVICES = 'electronic_services',
  INFORMATION_SECURITY = 'information_security',
  ENGINEERING = 'engineering',
  INFORMATION_APPLICATIONS = 'information_applications',
  OTHER = 'other',
}