export enum MarketScope {
  LOCAL = 'local',
  ARAB = 'arab',
  GLOBAL = 'global',
} 