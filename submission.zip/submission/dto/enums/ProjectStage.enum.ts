export enum ProjectStage {
  IDEA = 'idea',
  FEASIBILITY_STUDY = 'feasibility_study',
  IMPLEMENTATION_STARTED = 'implementation_started',
  IMPLEMENTATION_COMPLETED = 'implementation_completed',
}