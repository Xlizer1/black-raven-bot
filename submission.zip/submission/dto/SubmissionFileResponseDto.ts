import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsString, IsUrl, IsDateString } from 'class-validator';

export class SubmissionFileResponseDto {
  @ApiProperty({
    description: 'The unique identifier of the submission file',
    example: 1
  })
  @IsNumber()
  submission_file_id: number;

  @ApiProperty({
    description: 'The ID of the project submission this file belongs to',
    example: 123
  })
  @IsNumber()
  submission_id: number;

  @ApiProperty({
    description: 'Original name of the uploaded file',
    example: 'business-plan.pdf'
  })
  @IsString()
  file_name: string;

  @ApiProperty({
    description: 'Public URL where the file can be accessed',
    example: 'http://localhost:3000/uploads/project-submissions/123/abc-123.pdf'
  })
  @IsUrl()
  file_url: string;

  @ApiProperty({
    description: 'MIME type of the file',
    example: 'application/pdf'
  })
  @IsString()
  file_type: string;

  @ApiProperty({
    description: 'Timestamp when the file was uploaded',
    example: '2024-01-20T12:00:00Z'
  })
  @IsDateString()
  uploaded_at: string;
} 