import { Module, Global } from '@nestjs/common';
import { DatabaseModule } from 'src/infrastructure/database/drivers/database.module';
import { RedisModule } from 'src/infrastructure/external-services/redis/RedisModule';
import { SharedModule } from 'src/shared/shared.module';
import { PermissionModule } from 'src/shared/permission/permission.module';
import { InitiateProjectUseCase } from './core/application/use-cases/InitiateProjectUseCase';
import { ProjectSubmissionController } from './adapters/api/ProjectSubmissionController';
import { ProjectSubmissionRepository } from './adapters/repositories/ProjectSubmissionRepository';
import { ProductInfoUseCase } from './core/application/use-cases/ProductInfoUseCase';
import { MarketUseCase } from './core/application/use-cases/MarketUseCase';
import { IncubatorRoleUseCase } from './core/application/use-cases/IncubatorRoleUseCase';
import { TimelineFinanceUseCase } from './core/application/use-cases/TimelineFinanceUseCase';
import { ProjectWorkUseCase } from './core/application/use-cases/ProjectWorkUseCase';
import { SubmissionFileRepository } from './adapters/repositories/SubmissionFileRepository';
import { AttachSubmissionFilesUseCase } from './core/application/use-cases/AttachSubmissionFilesUseCase';
import { FileUploadModule } from 'src/infrastructure/external-services/file-upload/FileUpload.module';
import { SubmitProjectFormUseCase } from './core/application/use-cases/SubmitProjectFormUseCase';
import { InitiateProjectCommand } from './core/application/commands/InitiateProjectCommand';
import { AddProductInfoCommand } from './core/application/commands/AddProductInfoCommand';
import { AddMarketInfoCommand } from './core/application/commands/AddMarketInfoCommand';
import { AddIncubatorRoleCommand } from './core/application/commands/AddIncubatorRoleCommand';
import { AddTimelineFinanceCommand } from './core/application/commands/AddTimelineFinanceCommand';
import { AddProjectWorkCommand } from './core/application/commands/AddProjectWorkCommand';
import { SubmitProjectFormCommand } from './core/application/commands/SubmitProjectFormCommand';
import { AttachSubmissionFilesCommand } from './core/application/commands/AttachSubmissionFilesCommand';
import { FindProjectsByUserIdQuery } from './core/application/queries/FindProjectsByUserIdQuery';
import { FindProjectsByUserIdUseCase } from './core/application/use-cases/FindProjectsByUserIdUseCase';
import { GetIdeaUseCase } from './core/application/use-cases/GetIdeaUseCase';
import { GetIncubatorRoleUseCase } from './core/application/use-cases/GetIncubatorRoleUseCase';
import { GetInfoUseCase } from './core/application/use-cases/GetInfoUseCase';
import { GetMarketUseCase } from './core/application/use-cases/GetMarketUseCase';
import { GetProjectWorkUseCase } from './core/application/use-cases/GetProjectWorkUseCase';
import { GetSubmissionIdFilesUseCase } from './core/application/use-cases/GetSubmissionIdFilesUseCase';
import { GetTimelineFinanceUseCase } from './core/application/use-cases/GetTimelineFinanceUseCase';
import { GetIdeaQuery } from './core/application/queries/GetIdeaQuery';
import { GetIncubatorRoleQuery } from './core/application/queries/GetIncubatorRoleQuery';
import { GetInfoQuery } from './core/application/queries/GetInfoQuery';
import { GetMarketQuery } from './core/application/queries/GetMarketQuery';
import { GetProjectWorkQuery } from './core/application/queries/GetProjectWorkQuery';
import { GetSubmissionIdFilesQuery } from './core/application/queries/GetSubmissionIdFilesQuery';
import { GetTimelineFinanceQuery } from './core/application/queries/GetTimelineFinanceQuery';
import { UpdateIdeaCommand } from './core/application/commands/UpdateIdeaCommand';
import { UpdateMarketCommand } from './core/application/commands/UpdateMarketCommand';
import { UpdateIncubatorRoleCommand } from './core/application/commands/UpdateIncubatorRoleCommand';
import { UpdateTimelineFinanceCommand } from './core/application/commands/UpdateTimelineFinanceCommand';
import { UpdateProjectWorkCommand } from './core/application/commands/UpdateProjectWorkCommand';

import { UpdateIdeaUseCase } from './core/application/use-cases/UpdateIdeaUseCase';
import { UpdateMarketUseCase } from './core/application/use-cases/UpdateMarketUseCase';
import { UpdateIncubatorRoleUseCase } from './core/application/use-cases/UpdateIncubatorRoleUseCase';
import { UpdateTimelineFinanceUseCase } from './core/application/use-cases/UpdateTimelineFinanceUseCase';
import { UpdateProjectWorkUseCase } from './core/application/use-cases/UpdateProjectWorkUseCase';
import { UpdateProductInfoUseCase } from './core/application/use-cases/UpdateProductInfoUseCase';
import { UpdateProductInfoCommand } from './core/application/commands/UpdateProductInfoCommand';

@Global()
@Module({
  imports: [
    DatabaseModule,
    RedisModule,
    SharedModule,
    PermissionModule,
    FileUploadModule,
  ],
  controllers: [ProjectSubmissionController],
  providers: [
    // Use cases
    InitiateProjectUseCase,
    ProductInfoUseCase,
    MarketUseCase,
    IncubatorRoleUseCase,
    TimelineFinanceUseCase,
    ProjectWorkUseCase,
    AttachSubmissionFilesUseCase,
    SubmitProjectFormUseCase,
    FindProjectsByUserIdUseCase,
    GetIdeaUseCase,
    GetIncubatorRoleUseCase,
    GetInfoUseCase,
    GetMarketUseCase,
    GetProjectWorkUseCase,
    GetSubmissionIdFilesUseCase,
    GetTimelineFinanceUseCase,
    UpdateIdeaUseCase,
    UpdateProductInfoUseCase,
    UpdateMarketUseCase,
    UpdateIncubatorRoleUseCase,
    UpdateTimelineFinanceUseCase,
    UpdateProjectWorkUseCase,

    // Commands
    InitiateProjectCommand,
    AddProductInfoCommand,
    AddMarketInfoCommand,
    AddIncubatorRoleCommand,
    AddTimelineFinanceCommand,
    AddProjectWorkCommand,
    SubmitProjectFormCommand,
    AttachSubmissionFilesCommand,
    UpdateIdeaCommand,
    UpdateProductInfoCommand,
    UpdateMarketCommand,
    UpdateIncubatorRoleCommand,
    UpdateTimelineFinanceCommand,
    UpdateProjectWorkCommand,

    // Queries
    FindProjectsByUserIdQuery,
    GetIdeaQuery,
    GetIncubatorRoleQuery,
    GetInfoQuery,
    GetMarketQuery,
    GetProjectWorkQuery,
    GetSubmissionIdFilesQuery,
    GetTimelineFinanceQuery,

    ProjectSubmissionRepository,
    SubmissionFileRepository,
    {
      provide: 'IProjectSubmissionRepository',
      useClass: ProjectSubmissionRepository,
    },
    {
      provide: 'ISubmissionFileRepository',
      useClass: SubmissionFileRepository,
    },
  ],
  exports: ['IProjectSubmissionRepository', 'ISubmissionFileRepository'],
})
export class ProjectSubmissionModule {}
