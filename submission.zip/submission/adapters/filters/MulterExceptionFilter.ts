import { ExceptionFilter, Catch, ArgumentsHost, BadRequestException } from '@nestjs/common';
import { Response } from 'express';
import { MulterError } from 'multer';
import { FILE_UPLOAD_CONFIG } from '../../config/file-upload.config';

@Catch(MulterError, BadRequestException)
export class MulterExceptionFilter implements ExceptionFilter {
  catch(exception: MulterError | BadRequestException, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    
    let message: string;
    let details: any = {};

    if (exception instanceof MulterError) {
      switch (exception.code) {
        case 'LIMIT_FILE_SIZE':
          message = 'file_size_limit_exceeded';
          details = { limit: FILE_UPLOAD_CONFIG.MAX_FILE_SIZE };
          break;
        case 'LIMIT_FILE_COUNT':
          message = 'too_many_files_provided';
          details = { 
            limit: FILE_UPLOAD_CONFIG.MAX_FILES,
            count: exception.field 
          };
          break;
        case 'LIMIT_UNEXPECTED_FILE':
          message = 'unexpected_field_provided';
          details = { field: exception.field };
          break;
        default:
          message = 'failed_to_upload_files';
          details = { error: exception.message };
      }
    } else {
      // Handle BadRequestException
      const exceptionResponse = exception.getResponse() as any;
      if (exceptionResponse.message === 'Unexpected field') {
        message = 'unexpected_field_provided';
        details = { field: 'files' };
      } else if (exceptionResponse.message === 'Too many files') {
        message = 'too_many_files_provided';
        details = { 
          limit: FILE_UPLOAD_CONFIG.MAX_FILES,
          count: 'exceeded'
        };
      } else {
        message = 'failed_to_upload_files';
        details = { error: exceptionResponse.message };
      }
    }

    response.status(400).json({
      statusCode: 400,
      message: `common.${message}`,
      errors: { details },
      timestamp: new Date().toISOString(),
      path: ctx.getRequest().url
    });
  }
} 