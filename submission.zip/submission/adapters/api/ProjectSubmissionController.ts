import {
  Controller,
  HttpStatus,
  HttpCode,
  Get,
  Query,
  UseGuards,
  Post,
  Body,
  UseInterceptors,
  UploadedFiles,
  Param,
  Delete,
  UseFilters,
  ParseIntPipe,
  Patch,
} from '@nestjs/common';
import {
  ApiHelperService,
  ApiResponse,
  ErrorResponse,
} from '../../../../../shared/services/ApiHelperService';
import { LocalizationService } from 'src/shared/services/LocalizationService';
import { AuthGuard } from 'src/shared/guards/AuthGuard';
import { Permission } from 'src/shared/permission/decorators/permissions.decorator';
import { PermissionsGuard } from 'src/shared/permission/guards/permissions.guard';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { FindAllDto } from 'src/shared/dto/FindAllDto';
import { UserDecorator } from 'src/shared/decorators/user.decorator';
import { FilesInterceptor } from '@nestjs/platform-express';
import { AttachSubmissionFilesUseCase } from '../../core/application/use-cases/AttachSubmissionFilesUseCase';
import { InitiateProjectDto } from '../../dto/InitiateProjectDto';
import { ProductInfoDto } from '../../dto/ProductInfoDto';
import { MarketDto } from '../../dto/MarketDto';
import { IncubatorRoleDto } from '../../dto/IncubatorRoleDto';
import { TimelineFinanceDto } from '../../dto/TimelineFinanceDto';
import { ProjectWorkDto } from '../../dto/ProjectWorkDto';
import { ProjectResponseDto } from '../../dto/ProjectResponseDto';
import { InitiateProjectUseCase } from '../../core/application/use-cases/InitiateProjectUseCase';
import { ProductInfoUseCase } from '../../core/application/use-cases/ProductInfoUseCase';
import { MarketUseCase } from '../../core/application/use-cases/MarketUseCase';
import { IncubatorRoleUseCase } from '../../core/application/use-cases/IncubatorRoleUseCase';
import { TimelineFinanceUseCase } from '../../core/application/use-cases/TimelineFinanceUseCase';
import { ProjectWorkUseCase } from '../../core/application/use-cases/ProjectWorkUseCase';
import { SubmitProjectFormUseCase } from '../../core/application/use-cases/SubmitProjectFormUseCase';
import {
  FILE_UPLOAD_CONFIG,
  multerOptions,
} from '../../config/file-upload.config';
import { ApiConsumes, ApiBody } from '@nestjs/swagger';
import { MulterExceptionFilter } from '../filters/MulterExceptionFilter';
import { FindProjectsByUserIdUseCase } from '../../core/application/use-cases/FindProjectsByUserIdUseCase';

import { GetIdeaUseCase } from '../../core/application/use-cases/GetIdeaUseCase';
import { GetInfoUseCase } from '../../core/application/use-cases/GetInfoUseCase';
import { GetMarketUseCase } from '../../core/application/use-cases/GetMarketUseCase';
import { GetIncubatorRoleUseCase } from '../../core/application/use-cases/GetIncubatorRoleUseCase';
import { GetTimelineFinanceUseCase } from '../../core/application/use-cases/GetTimelineFinanceUseCase';
import { GetProjectWorkUseCase } from '../../core/application/use-cases/GetProjectWorkUseCase';
import { GetSubmissionIdFilesUseCase } from '../../core/application/use-cases/GetSubmissionIdFilesUseCase';
import { UpdateIdeaUseCase } from '../../core/application/use-cases/UpdateIdeaUseCase';
import { UpdateProductInfoUseCase } from '../../core/application/use-cases/UpdateProductInfoUseCase';
import { UpdateMarketUseCase } from '../../core/application/use-cases/UpdateMarketUseCase';
import { UpdateIncubatorRoleUseCase } from '../../core/application/use-cases/UpdateIncubatorRoleUseCase';
import { UpdateTimelineFinanceUseCase } from '../../core/application/use-cases/UpdateTimelineFinanceUseCase';
import { UpdateProjectWorkUseCase } from '../../core/application/use-cases/UpdateProjectWorkUseCase';

@UseGuards(AuthGuard, PermissionsGuard)
@ApiBearerAuth('JWT-auth')
@ApiTags('Project Submission')
@Controller('project/submission')
export class ProjectSubmissionController {
  constructor(
    private apiHelperService: ApiHelperService,

    private readonly initiateProjectUseCase: InitiateProjectUseCase,
    private readonly getIdeaUseCase: GetIdeaUseCase,
    private readonly updateIdeaUseCase: UpdateIdeaUseCase,

    private readonly productInfoUseCase: ProductInfoUseCase,
    private readonly getInfoUseCase: GetInfoUseCase,
    private readonly updateProductInfoUseCase: UpdateProductInfoUseCase,

    private readonly marketUseCase: MarketUseCase,
    private readonly getMarketUseCase: GetMarketUseCase,
    private readonly updateMarketUseCase: UpdateMarketUseCase,

    private readonly incubatorRoleUseCase: IncubatorRoleUseCase,
    private readonly getIncubatorRoleUseCase: GetIncubatorRoleUseCase,
    private readonly updateIncubatorRoleUseCase: UpdateIncubatorRoleUseCase,

    private readonly timelineFinanceUseCase: TimelineFinanceUseCase,
    private readonly getTimelineFinanceUseCase: GetTimelineFinanceUseCase,
    private readonly updateTimelineFinanceUseCase: UpdateTimelineFinanceUseCase,

    private readonly projectWorkUseCase: ProjectWorkUseCase,
    private readonly getProjectWorkUseCase: GetProjectWorkUseCase,
    private readonly updateProjectWorkUseCase: UpdateProjectWorkUseCase,
    
    private readonly attachSubmissionFilesUseCase: AttachSubmissionFilesUseCase,
    private readonly getSubmissionIdFilesUseCase: GetSubmissionIdFilesUseCase,

    
    private readonly localizationService: LocalizationService,
    private readonly submitProjectFormUseCase: SubmitProjectFormUseCase,
    private readonly findProjectsByUserIdUseCase: FindProjectsByUserIdUseCase,
  ) {}

  // @Permission('view_submission')
  @Get('/')
  @HttpCode(HttpStatus.OK)
  async findAllOwnProject(
    @Query() queryParams: FindAllDto,
    @UserDecorator('userId') userId: number,
  ): Promise<ApiResponse<ProjectResponseDto[]> | ErrorResponse> {
    const result = await this.findProjectsByUserIdUseCase.execute(userId, queryParams);

    return this.apiHelperService.sendSuccessResponse(
      result.data,
      this.localizationService.translate('fetch_successfully'),
      result.pagination
    );
  }

  /**
   * Step 1: Submit the project & project idea
   * only the user with 'create_submission' permission can submit projects
   * default to: entrepreneur role
   * @param data
   * @param userId
   * @returns
   */
  // @Permission('create_submission')
  @Post('/idea')
  @HttpCode(HttpStatus.OK)
  async initiateProject(
    @Body() data: InitiateProjectDto,
    @UserDecorator('userId') userId: number,
  ): Promise<ApiResponse<ProjectResponseDto> | ErrorResponse> {
    const result = await this.initiateProjectUseCase.execute(userId, data);
    return this.apiHelperService.sendSuccessResponse(
      result,
      this.localizationService.translate('project_initiated_successfully'),
    );
  }

  /**
   * Step 2: Submit the project & project idea
   * only the user with 'create_submission' permission can submit projects
   * default to: entrepreneur role
   * @param submissionId
   * @returns
   */
  // @Permission('view_submission')
  @Get('/idea/:submissionId')
  @HttpCode(HttpStatus.OK)
  async getIdea(
    @Param('submissionId', ParseIntPipe) submissionId: number
  ): Promise<ApiResponse<ProjectResponseDto> | ErrorResponse> {
    const result = await this.getIdeaUseCase.execute(submissionId);
    return this.apiHelperService.sendSuccessResponse(
      result,
      this.localizationService.translate('project_initiated_successfully'),
    );
  }
  /**
   * Step 2: Project info, the step required submission id from the step 1.
   * @param data
   * @param userId
   * @returns
   */
  // @Permission('create_submission')
  @Post('/info')
  @HttpCode(HttpStatus.OK)
  async productInfo(
    @Body() data: ProductInfoDto,
    @UserDecorator('userId') userId: number,
  ): Promise<ApiResponse<ProjectResponseDto> | ErrorResponse> {
    const result = await this.productInfoUseCase.execute(userId, data);
    return this.apiHelperService.sendSuccessResponse(
      result,
      this.localizationService.translate('fetch_successfully'),
    );
  }

  /**
   * Step 3: Submit the project & project idea
   * only the user with 'create_submission' permission can submit projects
   * default to: entrepreneur role
   * @param submissionId
   * @returns
   */
  // @Permission('view_submission')
  @Get('/info/:submissionId')
  @HttpCode(HttpStatus.OK)
  async getInfo(
    @Param('submissionId', ParseIntPipe) submissionId: number
  ): Promise<ApiResponse<ProjectResponseDto> | ErrorResponse> {
    const result = await this.getInfoUseCase.execute(submissionId);
    return this.apiHelperService.sendSuccessResponse(
      result,
      this.localizationService.translate('project_initiated_successfully'),
    );
  }

  /**
   * Step 3: Market and competitors
   * @param data
   * @param userId
   * @returns
   */
  // @Permission('create_submission')
  @Post('/market')
  @HttpCode(HttpStatus.OK)
  async marketInfo(
    @Body() data: MarketDto,
    @UserDecorator('userId') userId: number,
  ): Promise<ApiResponse<ProjectResponseDto> | ErrorResponse> {
    const result = await this.marketUseCase.execute(userId, data);
    return this.apiHelperService.sendSuccessResponse(
      result,
      this.localizationService.translate('fetch_successfully'),
    );
  }

  /**
   * Step 4: Submit the project & project idea
   * only the user with 'create_submission' permission can submit projects
   * default to: entrepreneur role
   * @param submissionId
   * @returns
   */
  // @Permission('view_submission')
  @Get('/market/:submissionId')
  @HttpCode(HttpStatus.OK)
  async getMarket(
    @Param('submissionId', ParseIntPipe) submissionId: number
  ): Promise<ApiResponse<ProjectResponseDto> | ErrorResponse> {
    const result = await this.getMarketUseCase.execute(submissionId);
    return this.apiHelperService.sendSuccessResponse(
      result,
      this.localizationService.translate('project_initiated_successfully'),
    );
  }

  /**
   * Step 4: Incubator Role and Project Requirements
   * @param data
   * @param userId
   * @returns
   */
  // @Permission('create_submission')
  @Post('/incubator-role')
  @HttpCode(HttpStatus.OK)
  async incubatorRoleInfo(
    @Body() data: IncubatorRoleDto,
    @UserDecorator('userId') userId: number,
  ): Promise<ApiResponse<ProjectResponseDto> | ErrorResponse> {
    const result = await this.incubatorRoleUseCase.execute(userId, data);
    return this.apiHelperService.sendSuccessResponse(
      result,
      this.localizationService.translate('fetch_successfully'),
    );
  }

  /**
   * Step 5: Submit the project & project idea
   * only the user with 'create_submission' permission can submit projects
   * default to: entrepreneur role
   * @param submissionId
   * @returns
   */
  // @Permission('view_submission')
  @Get('/incubator-role/:submissionId')
  @HttpCode(HttpStatus.OK)
  async getIncubatorRole(
    @Param('submissionId', ParseIntPipe) submissionId: number
  ): Promise<ApiResponse<ProjectResponseDto> | ErrorResponse> {
    const result = await this.getIncubatorRoleUseCase.execute(submissionId);
    return this.apiHelperService.sendSuccessResponse(
      result,
      this.localizationService.translate('project_initiated_successfully'),
    );
  }

  /**
   * Step 5: Project timeline and finance need
   * @param data
   * @param userId
   * @returns
   */
  // @Permission('create_submission')
  @Post('/timeline-finance')
  @HttpCode(HttpStatus.OK)
  async timelineFinanceInfo(
    @Body() data: TimelineFinanceDto,
    @UserDecorator('userId') userId: number,
  ): Promise<ApiResponse<ProjectResponseDto> | ErrorResponse> {
    const result = await this.timelineFinanceUseCase.execute(userId, data);
    return this.apiHelperService.sendSuccessResponse(
      result,
      this.localizationService.translate('fetch_successfully'),
    );
  }

  /**
   * Step 6: Submit the project & project idea
   * only the user with 'create_submission' permission can submit projects
   * default to: entrepreneur role
   * @param submissionId
   * @returns
   */
  // @Permission('view_submission')
  @Get('/timeline-finance/:submissionId')
  @HttpCode(HttpStatus.OK)
  async getTimelineFinance(
    @Param('submissionId', ParseIntPipe) submissionId: number
  ): Promise<ApiResponse<ProjectResponseDto> | ErrorResponse> {
    const result = await this.getTimelineFinanceUseCase.execute(submissionId);
    return this.apiHelperService.sendSuccessResponse(
      result,
      this.localizationService.translate('project_initiated_successfully'),
    );
  }

  /**
   * Step 6: Project Work
   * @param data
   * @param userId
   * @returns
   */
  // @Permission('create_submission')
  @Post('/project-work')
  @HttpCode(HttpStatus.OK)
  async projectWorkInfo(
    @Body() data: ProjectWorkDto,
    @UserDecorator('userId') userId: number,
  ): Promise<ApiResponse<ProjectResponseDto> | ErrorResponse> {
    const result = await this.projectWorkUseCase.execute(userId, data);
    return this.apiHelperService.sendSuccessResponse(
      result,
      this.localizationService.translate('fetch_successfully'),
    );
  }

  /**
   * Step 7: Submit the project & project idea
   * only the user with 'create_submission' permission can submit projects
   * default to: entrepreneur role
   * @param submissionId
   * @returns
   */
  // @Permission('view_submission')
  @Get('/project-work/:submissionId')
  @HttpCode(HttpStatus.OK)
  async getProjectWork(
    @Param('submissionId', ParseIntPipe) submissionId: number
  ): Promise<ApiResponse<ProjectResponseDto> | ErrorResponse> {
    const result = await this.getProjectWorkUseCase.execute(submissionId);
    return this.apiHelperService.sendSuccessResponse(
      result,
      this.localizationService.translate('project_initiated_successfully'),
    );
  }

  /**
   * Step 7: Upload files
   * @param files
   * @param submissionId
   * @param userId
   * @returns
   */
  // @Permission('create_submission')
  @Post('/:submissionId/files')
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        [FILE_UPLOAD_CONFIG.FIELD_NAME]: {
          type: 'array',
          items: {
            type: 'string',
            format: 'binary',
          },
        },
      },
    },
  })
  @UseFilters(new MulterExceptionFilter())
  @UseInterceptors(
    FilesInterceptor(
      FILE_UPLOAD_CONFIG.FIELD_NAME,
      FILE_UPLOAD_CONFIG.MAX_FILES,
      multerOptions,
    ),
  )
  async attachProjectFiles(
    @UploadedFiles() files: Express.Multer.File[],
    @Param('submissionId') submissionId: number,
    @UserDecorator('userId') userId: number,
  ) {
    const result = await this.attachSubmissionFilesUseCase.execute(
      userId,
      submissionId,
      files,
    );

    return this.apiHelperService.sendSuccessResponse(
      result,
      this.localizationService.translate('files_uploaded_successfully'),
    );
  }

  /**
   * Step 8: Submit the project & project idea
   * only the user with 'create_submission' permission can submit projects
   * default to: entrepreneur role
   * @param submissionId
   * @returns
   */
  // @Permission('view_submission')
  @Get('/:submissionId/files')
  @HttpCode(HttpStatus.OK)
  async getSubmissionIdFiles(
    @Param('submissionId', ParseIntPipe) submissionId: number
  ): Promise<ApiResponse<ProjectResponseDto> | ErrorResponse> {
    const result = await this.getSubmissionIdFilesUseCase.execute(submissionId);
    return this.apiHelperService.sendSuccessResponse(
      result,
      this.localizationService.translate('project_initiated_successfully'),
    );
  }

  /**
   * Step Final: submist project to review.
   * @param submissionId
   * @param userId
   * @returns
   */
  @Post('/submit/:submissionId')
  @HttpCode(HttpStatus.ACCEPTED)
  async submitProjectForm(
    @Param('submissionId') submissionId: number,
    @UserDecorator('userId') userId: number,
  ): Promise<ApiResponse<any>> {
    const result = await this.submitProjectFormUseCase.execute(
      userId,
      submissionId,
    );
    return this.apiHelperService.sendSuccessResponse(
      null,
      this.localizationService.translate('project_submitted_successfully'),
    );
  }

  /**
   * Update Step 1: Project idea & basic info
   * @param data
   * @param userId
   * @returns
   */
  // @Permission('update_submission')
  @Patch('/idea')
  @HttpCode(HttpStatus.OK)
  async updateIdea(
    @Body() data: InitiateProjectDto,
    @UserDecorator('userId') userId: number,
  ): Promise<ApiResponse<ProjectResponseDto> | ErrorResponse> {
    const result = await this.updateIdeaUseCase.execute(userId, data);
    return this.apiHelperService.sendSuccessResponse(
      result,
      this.localizationService.translate('project_idea_updated_successfully'),
    );
  }

  /**
   * Update Step 2: Product information
   * @param data
   * @param userId
   * @returns
   */
  // @Permission('update_submission')
  @Patch('/info')
  @HttpCode(HttpStatus.OK)
  async updateProductInfo(
    @Body() data: ProductInfoDto,
    @UserDecorator('userId') userId: number,
  ): Promise<ApiResponse<ProjectResponseDto> | ErrorResponse> {
    const result = await this.updateProductInfoUseCase.execute(userId, data);
    return this.apiHelperService.sendSuccessResponse(
      result,
      this.localizationService.translate('product_info_updated_successfully'),
    );
  }

  /**
   * Update Step 3: Market and competitors
   * @param data
   * @param userId
   * @returns
   */
  // @Permission('update_submission')
  @Patch('/market')
  @HttpCode(HttpStatus.OK)
  async updateMarket(
    @Body() data: MarketDto,
    @UserDecorator('userId') userId: number,
  ): Promise<ApiResponse<ProjectResponseDto> | ErrorResponse> {
    const result = await this.updateMarketUseCase.execute(userId, data);
    return this.apiHelperService.sendSuccessResponse(
      result,
      this.localizationService.translate('market_info_updated_successfully'),
    );
  }

  /**
   * Update Step 4: Incubator Role and Project Requirements
   * @param data
   * @param userId
   * @returns
   */
  // @Permission('update_submission')
  @Patch('/incubator-role')
  @HttpCode(HttpStatus.OK)
  async updateIncubatorRole(
    @Body() data: IncubatorRoleDto,
    @UserDecorator('userId') userId: number,
  ): Promise<ApiResponse<ProjectResponseDto> | ErrorResponse> {
    const result = await this.updateIncubatorRoleUseCase.execute(userId, data);
    return this.apiHelperService.sendSuccessResponse(
      result,
      this.localizationService.translate('incubator_role_updated_successfully'),
    );
  }

  /**
   * Update Step 5: Project timeline and finance need
   * @param data
   * @param userId
   * @returns
   */
  // @Permission('update_submission')
  @Patch('/timeline-finance')
  @HttpCode(HttpStatus.OK)
  async updateTimelineFinance(
    @Body() data: TimelineFinanceDto,
    @UserDecorator('userId') userId: number,
  ): Promise<ApiResponse<ProjectResponseDto> | ErrorResponse> {
    const result = await this.updateTimelineFinanceUseCase.execute(userId, data);
    return this.apiHelperService.sendSuccessResponse(
      result,
      this.localizationService.translate('timeline_finance_updated_successfully'),
    );
  }

  /**
   * Update Step 6: Project Work
   * @param data
   * @param userId
   * @returns
   */
  // @Permission('update_submission')
  @Patch('/project-work')
  @HttpCode(HttpStatus.OK)
  async updateProjectWork(
    @Body() data: ProjectWorkDto,
    @UserDecorator('userId') userId: number,
  ): Promise<ApiResponse<ProjectResponseDto> | ErrorResponse> {
    const result = await this.updateProjectWorkUseCase.execute(userId, data);
    return this.apiHelperService.sendSuccessResponse(
      result,
      this.localizationService.translate('project_work_updated_successfully'),
    );
  }
}
