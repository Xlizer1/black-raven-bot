import {
  Controller,
  HttpStatus,
  HttpCode,
  Get,
  Query,
  UseGuards
} from '@nestjs/common';
import {
  ApiHelperService,
  ApiResponse,
  ErrorResponse
} from '../../../../../shared/services/ApiHelperService';
import { LocalizationService } from 'src/shared/services/LocalizationService';
import { AuthGuard } from 'src/shared/guards/AuthGuard';
import { Permission } from 'src/shared/permission/decorators/permissions.decorator';
import { PermissionsGuard } from 'src/shared/permission/guards/permissions.guard';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { FindAllDto } from 'src/shared/dto/FindAllDto';

@UseGuards(AuthGuard, PermissionsGuard)
@ApiBearerAuth('JWT-auth')
@ApiTags('Project Admin Submission')
@Controller('admin/project/submission')
export class AdminProjectController {
  constructor(
    private apiHelperService: ApiHelperService,
    private readonly localizationService: LocalizationService,
  ) {}
  
  /**
   * 
   */
  @Permission('view_all_project')
  @Get()
  @HttpCode(HttpStatus.OK)
  async findAllProject(
    @Query() queryParams: FindAllDto,
  ): Promise<
    | ApiResponse<any>
    | ErrorResponse
  > {
    return this.apiHelperService.sendSuccessResponse(
      "", 
      this.localizationService.translate('fetch_successfully'),
    );
  }
}
