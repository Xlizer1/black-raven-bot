import { Injectable } from '@nestjs/common';
import { DatabaseService } from 'src/infrastructure/database/drivers/database.service';
import { ISubmissionFileRepository } from '../../core/domain/interfaces/ISubmissionFileRepository';
import { UnauthorizedFileAccessError, FileDeletionFailedException } from '../../core/domain/exceptions/ProjectSubmissionError';

@Injectable()
export class SubmissionFileRepository implements ISubmissionFileRepository {
  constructor(private readonly databaseService: DatabaseService) {}

  async attachFiles(
    userId: number,
    submissionId: number,
    fileMetadata: {
      fileName: string;
      fileUrl: string;
      fileType: string;
      filePath: string;
    }[]
  ): Promise<any[]> {
    try {
      // Start transaction
      await this.databaseService.query('BEGIN');

      // Verify submission ownership
      const checkQuery = `
        SELECT submission_id FROM project.submission
        WHERE submission_id = $1 AND user_id = $2
      `;
      const checkResult = await this.databaseService.query(checkQuery, [submissionId, userId]);

      if (checkResult.rowCount === 0) {
        await this.databaseService.query('ROLLBACK');
        throw new UnauthorizedFileAccessError();
      }

      // Insert all files sequentially within the same transaction
      const insertQuery = `
        INSERT INTO project.submission_file (
          submission_id,
          file_name,
          file_url,
          file_type
        )
        VALUES ($1, $2, $3, $4)
        RETURNING *
      `;

      const results = [];
      for (const file of fileMetadata) {
        const result = await this.databaseService.query(insertQuery, [
          submissionId,
          file.fileName,
          file.fileUrl,
          file.fileType
        ]);
        results.push(result.rows[0]);
      }

      await this.databaseService.query('COMMIT');
      return results;
    } catch (error) {
      await this.databaseService.query('ROLLBACK');
      throw error;
    }
  }

  async getFilesBySubmissionId(submissionId: number): Promise<any[]> {
    const query = `
      SELECT * FROM project.submission_file
      WHERE submission_id = $1
      ORDER BY uploaded_at DESC
    `;

    const result = await this.databaseService.query(query, [submissionId]);
    return result.rows;
  }

  async deleteFile(userId: number, submissionFileId: number): Promise<void> {
    // First verify user owns the submission
    const checkQuery = `
      SELECT sf.submission_file_id
      FROM project.submission_file sf
      JOIN project.submission s ON s.submission_id = sf.submission_id
      WHERE sf.submission_file_id = $1 AND s.user_id = $2
    `;
    const checkResult = await this.databaseService.query(checkQuery, [submissionFileId, userId]);

    if (checkResult.rowCount === 0) {
      throw new UnauthorizedFileAccessError();
    }

    const query = `
      DELETE FROM project.submission_file
      WHERE submission_file_id = $1
      RETURNING submission_file_id
    `;

    const result = await this.databaseService.query(query, [submissionFileId]);
    if (result.rowCount === 0) {
      throw new FileDeletionFailedException();
    }
  }
} 