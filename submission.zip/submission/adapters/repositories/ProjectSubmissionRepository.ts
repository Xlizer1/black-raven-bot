import { Injectable } from '@nestjs/common';
import { DatabaseService } from 'src/infrastructure/database/drivers/database.service';
import { IProjectSubmissionRepository } from '../../core/domain/interfaces/IProjectSubmissionRepository';
import { IProjectInitiation } from '../../core/domain/interfaces/IProjectInitiation';
import { ProjectSubmissionEntity } from '../../core/domain/entities/ProjectSubmissionEntity';
import { ProjectMapper } from '../../core/domain/mappers/ProjectMapper';
import { ProductInfoMapper } from '../../core/domain/mappers/ProductInfoMapper';
import { MarketMapper } from '../../core/domain/mappers/MarketMapper';
import { IncubatorRoleMapper } from '../../core/domain/mappers/IncubatorRoleMapper';
import { TimelineFinanceMapper } from '../../core/domain/mappers/TimelineFinanceMapper';
import { ProjectWorkMapper } from '../../core/domain/mappers/ProjectWorkMapper';
import {
  ProjectInitiationFailedException,
  MarketInfoUpdateFailedException,
  IncubatorRoleUpdateFailedException,
  TimelineFinanceUpdateFailedException,
  ProjectWorkUpdateFailedException,
  ProductInfoUpdateFailedException,
} from '../../core/domain/exceptions/ProjectSubmissionError';
import { MarketDto } from '../../dto/MarketDto';
import { IncubatorRoleDto } from '../../dto/IncubatorRoleDto';
import { TimelineFinanceDto } from '../../dto/TimelineFinanceDto';
import { ProjectWorkDto } from '../../dto/ProjectWorkDto';
import { TableNames } from 'src/infrastructure/database/TableNames';
import { Pagination } from 'src/shared/services/ApiHelperService';
import { InitiateProjectDto } from '../../dto/InitiateProjectDto';
import { ProductInfoDto } from '../../dto/ProductInfoDto';

@Injectable()
export class ProjectSubmissionRepository
  implements IProjectSubmissionRepository
{
  constructor(private readonly databaseService: DatabaseService) {}

  async initiateProject(
    userId: number,
    projectInitiation: IProjectInitiation,
  ): Promise<ProjectSubmissionEntity | null> {
    try {
      // Start transaction
      await this.databaseService.query('BEGIN');

      // Create submission record
      const submissionQuery = `
        INSERT INTO project.submission (user_id, status, form_version)
        VALUES ($1, 'draft', 1)
        RETURNING *
      `;
      const submissionResult = await this.databaseService.query(
        submissionQuery,
        [userId],
      );

      if (submissionResult.rowCount === 0) {
        await this.databaseService.query('ROLLBACK');
        return null;
      }

      const submission = submissionResult.rows[0];
      const submissionId = submission.submission_id;

      // Create submission detail record with initiation fields
      const detailQuery = `
        INSERT INTO project.submission_detail (
          submission_id,
          project_idea,
          project_stage,
          field_of_work,
          field_other,
          project_strengths
        )
        VALUES ($1, $2, $3, $4, $5, $6)
        RETURNING *
      `;

      const detailParams = [
        submissionId,
        projectInitiation.projectIdea,
        projectInitiation.projectStage,
        projectInitiation.fieldOfWork, // PostgreSQL will handle array conversion
        projectInitiation.fieldOther || null,
        projectInitiation.projectStrengths,
      ];

      const detailResult = await this.databaseService.query(
        detailQuery,
        detailParams,
      );

      if (detailResult.rowCount === 0) {
        await this.databaseService.query('ROLLBACK');
        return null;
      }

      // Commit transaction
      await this.databaseService.query('COMMIT');

      // Combine submission and detail data for mapping
      const combinedData = {
        ...submission,
        ...detailResult.rows[0],
      };

      return ProjectMapper.fromDatabase(combinedData);
    } catch (error) {
      await this.databaseService.query('ROLLBACK');
      throw new ProjectInitiationFailedException();
    }
  }

  async addProductInfo(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null> {
    try {
      // Check if submission exists and belongs to user
      const checkQuery = `
        SELECT submission_id FROM project.submission
        WHERE submission_id = $1 AND user_id = $2
      `;
      const checkResult = await this.databaseService.query(checkQuery, [
        data.submissionId,
        userId,
      ]);

      if (checkResult.rowCount === 0) {
        throw new Error('Submission not found or unauthorized');
      }

      // Update product info fields
      const updateQuery = `
        UPDATE project.submission_detail
        SET
          main_product = $1,
          similar_products = $2,
          product_need = $3,
          target_customers = $4,
          update_stages = $5,
          selling_method = $6,
          innovation = $7
        WHERE submission_id = $8
        RETURNING *
      `;

      const updateParams = [
        data.mainProduct,
        data.similarProducts || null,
        data.productNeed,
        data.targetCustomers,
        data.updateStages || null,
        data.sellingMethod,
        data.innovation,
        data.submissionId,
      ];

      const updateResult = await this.databaseService.query(
        updateQuery,
        updateParams,
      );

      if (updateResult.rowCount === 0) {
        return null;
      }

      // Get complete submission data with product info
      const query = `
        SELECT 
          s.*,
          sd.project_idea,
          sd.project_stage,
          sd.field_of_work,
          sd.field_other,
          sd.project_strengths,
          sd.main_product,
          sd.similar_products,
          sd.product_need,
          sd.target_customers,
          sd.update_stages,
          sd.selling_method,
          sd.innovation
        FROM project.submission s
        LEFT JOIN project.submission_detail sd ON s.submission_id = sd.submission_id
        WHERE s.submission_id = $1 AND s.user_id = $2
      `;

      const fetchResult = await this.databaseService.query(query, [
        data.submissionId,
        userId,
      ]);

      if (fetchResult.rowCount === 0) {
        return null;
      }

      return ProductInfoMapper.fromDatabase(fetchResult.rows[0]);
    } catch (error) {
      throw new Error('Failed to update product information');
    }
  }

  async findByUserId(
    userId: number,
    searchBy: string,
    searchValue: string,
    filterBy: string,
    filterValue: string,
    offset: number,
    pageSize: number,
    currentPage: number,
  ): Promise<{ pagination: Pagination; data: ProjectSubmissionEntity[] }> {
    // Base queries for data and count
    let baseQuery = `
      SELECT
        s.*,
        sd.project_idea,
        sd.project_stage,
        sd.field_of_work,
        sd.field_other,
        sd.project_strengths,
        sd.main_product,
        sd.similar_products,
        sd.product_need,
        sd.target_customers,
        sd.update_stages,
        sd.selling_method,
        sd.innovation
      FROM project.submission s
      LEFT JOIN project.submission_detail sd ON s.submission_id = sd.submission_id
    `;

    let baseCountQuery = `
      SELECT COUNT(*) AS total_count
      FROM project.submission s
      LEFT JOIN project.submission_detail sd ON s.submission_id = sd.submission_id
    `;

    // Initialize parameters for queries
    const whereConditions = [];
    const params = [];

    // Always filter by user_id
    whereConditions.push(`s.user_id = $${params.length + 1}`);
    params.push(userId);

    // Add search conditions if applicable (text-based searches)
    if (searchBy && searchValue) {
      switch (searchBy) {
        case 'project_idea':
          whereConditions.push(`sd.project_idea ILIKE $${params.length + 1}`);
          params.push(`%${searchValue}%`);
          break;
        case 'main_product':
          whereConditions.push(`sd.main_product ILIKE $${params.length + 1}`);
          params.push(`%${searchValue}%`);
          break;
        case 'target_customers':
          whereConditions.push(
            `sd.target_customers ILIKE $${params.length + 1}`,
          );
          params.push(`%${searchValue}%`);
          break;
        case 'innovation':
          whereConditions.push(`sd.innovation ILIKE $${params.length + 1}`);
          params.push(`%${searchValue}%`);
          break;
        default:
        // Do nothing for unknown search fields
      }
    }

    // Add filter conditions if applicable (exact matches/dropdown filters)
    if (filterBy && filterValue && filterValue !== 'all') {
      switch (filterBy) {
        case 'status':
          whereConditions.push(`s.status = $${params.length + 1}`);
          params.push(filterValue);
          break;
        case 'project_stage':
          whereConditions.push(`sd.project_stage = $${params.length + 1}`);
          params.push(filterValue);
          break;
        case 'form_version':
          whereConditions.push(`s.form_version = $${params.length + 1}`);
          params.push(parseInt(filterValue));
          break;
        case 'field_of_work':
          // Handle array field - check if filterValue exists in the array
          whereConditions.push(`$${params.length + 1} = ANY(sd.field_of_work)`);
          params.push(filterValue);
          break;
        case 'market_scope':
          whereConditions.push(`sd.market_scope = $${params.length + 1}`);
          params.push(filterValue);
          break;
        default:
        // Do nothing for unknown filter fields
      }
    }

    // Append WHERE clause if conditions exist
    if (whereConditions.length > 0) {
      const whereClause = `WHERE ${whereConditions.join(' AND ')}`;
      baseQuery += ` ${whereClause}`;
      baseCountQuery += ` ${whereClause}`;
    }

    // Add ORDER BY, OFFSET, and LIMIT for main query
    baseQuery += `
      ORDER BY s.created_at DESC
      OFFSET $${params.length + 1} LIMIT $${params.length + 2}
    `;
    params.push(offset, pageSize);

    // Execute count query to get total rows (exclude offset and limit params)
    const countResult = await this.databaseService.query(
      baseCountQuery,
      params.slice(0, params.length - 2), // Exclude offset and limit
    );
    const totalRows = parseInt(countResult.rows[0]?.total_count || '0', 10);

    // Calculate total pages
    const totalPages = Math.ceil(totalRows / pageSize);

    // Execute main query to fetch paginated data
    const result = await this.databaseService.query(baseQuery, params);

    // Handle empty results
    if (result.rowCount === 0) {
      return {
        pagination: {
          total_items: 0,
          total_pages: 0,
          current_page: currentPage,
          page_size: pageSize,
        },
        data: [],
      };
    }

    // Map rows to entities
    const data = result.rows.map(ProjectMapper.fromDatabase);

    // Pagination metadata
    const pagination: Pagination = {
      total_items: totalRows,
      total_pages: totalPages,
      current_page: currentPage,
      page_size: pageSize,
    };

    return { pagination, data };
  }

  async addMarketInfo(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null> {
    try {
      // Check if submission exists and belongs to user
      const checkQuery = `
        SELECT submission_id FROM project.submission
        WHERE submission_id = $1 AND user_id = $2
      `;
      const checkResult = await this.databaseService.query(checkQuery, [
        data.submissionId,
        userId,
      ]);

      if (checkResult.rowCount === 0) {
        throw new Error('Submission not found or unauthorized');
      }

      // Update market info fields
      const updateQuery = `
        UPDATE project.submission_detail
        SET
          market_ready_date = $1,
          market_needs = $2,
          other_products = $3,
          market_scope = $4,
          expected_customers = $5
        WHERE submission_id = $6
        RETURNING *
      `;

      const updateParams = [
        data.marketReadyDate || null,
        data.marketNeeds,
        data.otherProducts || null,
        data.marketScope,
        data.expectedCustomers,
        data.submissionId,
      ];

      const updateResult = await this.databaseService.query(
        updateQuery,
        updateParams,
      );

      if (updateResult.rowCount === 0) {
        return null;
      }

      // Get complete submission data with market info
      const query = `
        SELECT 
          s.*,
          sd.project_idea,
          sd.project_stage,
          sd.field_of_work,
          sd.field_other,
          sd.project_strengths,
          sd.main_product,
          sd.similar_products,
          sd.product_need,
          sd.target_customers,
          sd.update_stages,
          sd.selling_method,
          sd.innovation,
          sd.market_ready_date,
          sd.market_needs,
          sd.expected_customers,
          sd.other_products,
          sd.market_scope
        FROM project.submission s
        LEFT JOIN project.submission_detail sd ON s.submission_id = sd.submission_id
        WHERE s.submission_id = $1 AND s.user_id = $2
      `;

      const fetchResult = await this.databaseService.query(query, [
        data.submissionId,
        userId,
      ]);

      if (fetchResult.rowCount === 0) {
        return null;
      }

      return MarketMapper.fromDatabase(fetchResult.rows[0]);
    } catch (error) {
      throw new MarketInfoUpdateFailedException();
    }
  }

  async addIncubatorRoleInfo(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null> {
    try {
      // Check if submission exists and belongs to user
      const checkQuery = `
        SELECT submission_id FROM project.submission
        WHERE submission_id = $1 AND user_id = $2
      `;
      const checkResult = await this.databaseService.query(checkQuery, [
        data.submissionId,
        userId,
      ]);

      if (checkResult.rowCount === 0) {
        throw new Error('Submission not found or unauthorized');
      }

      // Update incubator role info fields
      const updateQuery = `
        UPDATE project.submission_detail
        SET
          incubator_benefits = $1,
          project_requirements = $2
        WHERE submission_id = $3
        RETURNING *
      `;

      const updateParams = [
        data.incubatorBenefits,
        data.projectRequirements,
        data.submissionId,
      ];

      const updateResult = await this.databaseService.query(
        updateQuery,
        updateParams,
      );

      if (updateResult.rowCount === 0) {
        return null;
      }

      // Get complete submission data with incubator role info
      const query = `
        SELECT 
          s.*,
          sd.project_idea,
          sd.project_stage,
          sd.field_of_work,
          sd.field_other,
          sd.project_strengths,
          sd.main_product,
          sd.similar_products,
          sd.product_need,
          sd.target_customers,
          sd.update_stages,
          sd.selling_method,
          sd.innovation,
          sd.market_ready_date,
          sd.market_needs,
          sd.other_products,
          sd.market_scope,
          sd.incubator_benefits,
          sd.project_requirements
        FROM project.submission s
        LEFT JOIN project.submission_detail sd ON s.submission_id = sd.submission_id
        WHERE s.submission_id = $1 AND s.user_id = $2
      `;

      const fetchResult = await this.databaseService.query(query, [
        data.submissionId,
        userId,
      ]);

      if (fetchResult.rowCount === 0) {
        return null;
      }

      return IncubatorRoleMapper.fromDatabase(fetchResult.rows[0]);
    } catch (error) {
      throw new IncubatorRoleUpdateFailedException();
    }
  }

  async addTimelineFinanceInfo(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null> {
    try {
      // Check if submission exists and belongs to user
      const checkQuery = `
        SELECT submission_id FROM project.submission
        WHERE submission_id = $1 AND user_id = $2
      `;
      const checkResult = await this.databaseService.query(checkQuery, [
        data.submissionId,
        userId,
      ]);

      if (checkResult.rowCount === 0) {
        throw new Error('Submission not found or unauthorized');
      }

      // Update timeline & finance info fields
      const updateQuery = `
        UPDATE project.submission_detail
        SET
          phase_1_desc = $1,
          phase_1_duration = $2,
          phase_2_desc = $3,
          phase_2_duration = $4,
          phase_3_desc = $5,
          phase_3_duration = $6,
          phase_4_desc = $7,
          phase_4_duration = $8,
          sales_increase_6mo = $9,
          sales_increase_12mo = $10,
          sales_increase_24mo = $11,
          estimated_investment_cost = $12,
          estimated_funding_needed = $13,
          funding_sources = $14
        WHERE submission_id = $15
        RETURNING *
      `;

      const updateParams = [
        data.phase1Desc,
        data.phase1Duration,
        data.phase2Desc,
        data.phase2Duration,
        data.phase3Desc,
        data.phase3Duration,
        data.phase4Desc,
        data.phase4Duration,
        data.salesIncrease6mo,
        data.salesIncrease12mo,
        data.salesIncrease24mo,
        data.estimatedInvestmentCost,
        data.estimatedFundingNeeded,
        data.fundingSources,
        data.submissionId,
      ];

      const updateResult = await this.databaseService.query(
        updateQuery,
        updateParams,
      );

      if (updateResult.rowCount === 0) {
        return null;
      }

      // Get complete submission data with timeline & finance info
      const query = `
        SELECT 
          s.*,
          sd.project_idea,
          sd.project_stage,
          sd.field_of_work,
          sd.field_other,
          sd.project_strengths,
          sd.main_product,
          sd.similar_products,
          sd.product_need,
          sd.target_customers,
          sd.update_stages,
          sd.selling_method,
          sd.innovation,
          sd.market_ready_date,
          sd.market_needs,
          sd.other_products,
          sd.market_scope,
          sd.incubator_benefits,
          sd.project_requirements,
          sd.phase_1_desc,
          sd.phase_1_duration,
          sd.phase_2_desc,
          sd.phase_2_duration,
          sd.phase_3_desc,
          sd.phase_3_duration,
          sd.phase_4_desc,
          sd.phase_4_duration,
          sd.sales_increase_6mo,
          sd.sales_increase_12mo,
          sd.sales_increase_24mo,
          sd.estimated_investment_cost,
          sd.estimated_funding_needed,
          sd.funding_sources
        FROM project.submission s
        LEFT JOIN project.submission_detail sd ON s.submission_id = sd.submission_id
        WHERE s.submission_id = $1 AND s.user_id = $2
      `;

      const fetchResult = await this.databaseService.query(query, [
        data.submissionId,
        userId,
      ]);

      if (fetchResult.rowCount === 0) {
        return null;
      }

      return TimelineFinanceMapper.fromDatabase(fetchResult.rows[0]);
    } catch (error) {
      console.error('Timeline Finance Update Error:', error);
      throw new TimelineFinanceUpdateFailedException();
    }
  }

  async addProjectWorkInfo(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null> {
    try {
      // Check if submission exists and belongs to user
      const checkQuery = `
        SELECT submission_id FROM project.submission
        WHERE submission_id = $1 AND user_id = $2
      `;
      const checkResult = await this.databaseService.query(checkQuery, [
        data.submissionId,
        userId,
      ]);

      if (checkResult.rowCount === 0) {
        throw new Error('Submission not found or unauthorized');
      }

      // Update project work info fields
      const updateQuery = `
        UPDATE project.submission_detail
        SET
          ownership_structure = $1,
          daily_management = $2,
          employee_count = $3,
          needed_skills = $4,
          activity_nature = $5
        WHERE submission_id = $6
        RETURNING *
      `;

      const updateParams = [
        data.ownershipStructure,
        data.dailyManagement,
        data.employeeCount,
        data.neededSkills,
        data.activityNature,
        data.submissionId,
      ];

      const updateResult = await this.databaseService.query(
        updateQuery,
        updateParams,
      );

      if (updateResult.rowCount === 0) {
        return null;
      }

      // Get complete submission data with project work info
      const query = `
        SELECT 
          s.*,
          sd.project_idea,
          sd.project_stage,
          sd.field_of_work,
          sd.field_other,
          sd.project_strengths,
          sd.main_product,
          sd.similar_products,
          sd.product_need,
          sd.target_customers,
          sd.update_stages,
          sd.selling_method,
          sd.innovation,
          sd.market_ready_date,
          sd.market_needs,
          sd.other_products,
          sd.market_scope,
          sd.incubator_benefits,
          sd.project_requirements,
          sd.phase_1_desc,
          sd.phase_1_duration,
          sd.phase_2_desc,
          sd.phase_2_duration,
          sd.phase_3_desc,
          sd.phase_3_duration,
          sd.phase_4_desc,
          sd.phase_4_duration,
          sd.sales_increase_6mo,
          sd.sales_increase_12mo,
          sd.sales_increase_24mo,
          sd.estimated_investment_cost,
          sd.estimated_funding_needed,
          sd.funding_sources,
          sd.ownership_structure,
          sd.daily_management,
          sd.employee_count,
          sd.needed_skills,
          sd.activity_nature
        FROM project.submission s
        LEFT JOIN project.submission_detail sd ON s.submission_id = sd.submission_id
        WHERE s.submission_id = $1 AND s.user_id = $2
      `;

      const fetchResult = await this.databaseService.query(query, [
        data.submissionId,
        userId,
      ]);

      if (fetchResult.rowCount === 0) {
        return null;
      }

      return ProjectWorkMapper.fromDatabase(fetchResult.rows[0]);
    } catch (error) {
      throw new ProjectWorkUpdateFailedException();
    }
  }

  async submitProjectForm(userId: number, submissionId: number) {
    const query = `
      UPDATE ${TableNames.SUBMISSION}
      SET
        status = 'submitted',
        submission_date = NOW()
      WHERE
        user_id = $1
      AND
        submission_id = $2
    `;

    await this.databaseService.query(query, [userId, submissionId]);
  }

  async getIdea(submissionId: number): Promise<any> {
    try {
      const query = `
        SELECT 
          project_idea,
          project_stage,
          field_of_work,
          field_other,
          project_strengths
        FROM project.submission_detail 
        WHERE submission_id = $1
      `;
      
      const result = await this.databaseService.query(query, [submissionId]);
      
      if (result.rowCount === 0) {
        return null;
      }
      
      return result.rows[0];
    } catch (error) {
      throw new Error(`Failed to retrieve project idea for submission ${submissionId}: ${error.message}`);
    }
  }

  async getInfo(submissionId: number): Promise<any> {
    try {
      const query = `
        SELECT 
          main_product,
          similar_products,
          product_need,
          target_customers,
          update_stages,
          selling_method,
          innovation
        FROM project.submission_detail 
        WHERE submission_id = $1
      `;
      
      const result = await this.databaseService.query(query, [submissionId]);
      
      if (result.rowCount === 0) {
        return null;
      }
      
      return result.rows[0];
    } catch (error) {
      throw new Error(`Failed to retrieve product info for submission ${submissionId}: ${error.message}`);
    }
  }

  async getIncubatorRole(submissionId: number): Promise<any> {
    try {
      const query = `
        SELECT 
          incubator_benefits,
          project_requirements
        FROM project.submission_detail 
        WHERE submission_id = $1
      `;
      
      const result = await this.databaseService.query(query, [submissionId]);
      
      if (result.rowCount === 0) {
        return null;
      }
      
      return result.rows[0];
    } catch (error) {
      throw new Error(`Failed to retrieve incubator role info for submission ${submissionId}: ${error.message}`);
    }
  }

  async getMarket(submissionId: number): Promise<any> {
    try {
      const query = `
        SELECT 
          market_ready_date,
          market_needs,
          expected_customers,
          other_products,
          market_scope
        FROM project.submission_detail 
        WHERE submission_id = $1
      `;
      
      const result = await this.databaseService.query(query, [submissionId]);
      
      if (result.rowCount === 0) {
        return null;
      }
      
      return result.rows[0];
    } catch (error) {
      throw new Error(`Failed to retrieve market info for submission ${submissionId}: ${error.message}`);
    }
  }

  async getProjectWork(submissionId: number): Promise<any> {
    try {
      const query = `
        SELECT 
          ownership_structure,
          daily_management,
          employee_count,
          needed_skills,
          activity_nature
        FROM project.submission_detail 
        WHERE submission_id = $1
      `;
      
      const result = await this.databaseService.query(query, [submissionId]);
      
      if (result.rowCount === 0) {
        return null;
      }
      
      return result.rows[0];
    } catch (error) {
      throw new Error(`Failed to retrieve project work info for submission ${submissionId}: ${error.message}`);
    }
  }

  async getSubmissionIdFiles(submissionId: number): Promise<any> {
    try {
      const query = `
        SELECT 
          submission_file_id,
          file_name,
          file_url,
          file_type
        FROM project.submission_file 
        WHERE submission_id = $1
      `;
      
      const result = await this.databaseService.query(query, [submissionId]);
      
      if (result.rowCount === 0) {
        return [];
      }
      
      return result.rows;
    } catch (error) {
      throw new Error(`Failed to retrieve files for submission ${submissionId}: ${error.message}`);
    }
  }

  async getTimelineFinance(submissionId: number): Promise<any> {
    try {
      const query = `
        SELECT 
          phase_1_desc,
          phase_1_duration,
          phase_2_desc,
          phase_2_duration,
          phase_3_desc,
          phase_3_duration,
          phase_4_desc,
          phase_4_duration,
          sales_increase_6mo,
          sales_increase_12mo,
          sales_increase_24mo,
          estimated_investment_cost,
          estimated_funding_needed,
          funding_sources
        FROM project.submission_detail 
        WHERE submission_id = $1
      `;
      
      const result = await this.databaseService.query(query, [submissionId]);
      
      if (result.rowCount === 0) {
        return null;
      }
      
      return result.rows[0];
    } catch (error) {
      throw new Error(`Failed to retrieve timeline finance info for submission ${submissionId}: ${error.message}`);
    }
  }

  async updateIdea(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null> {
    try {
      // Check if submission exists and belongs to user
      const checkQuery = `
        SELECT submission_id FROM project.submission
        WHERE submission_id = $1 AND user_id = $2
      `;
      const checkResult = await this.databaseService.query(checkQuery, [
        data.submissionId,
        userId,
      ]);

      if (checkResult.rowCount === 0) {
        throw new Error('Submission not found or unauthorized');
      }

      // Update idea fields
      const updateQuery = `
        UPDATE project.submission_detail
        SET
          project_idea = $1,
          project_stage = $2,
          field_of_work = $3,
          field_other = $4,
          project_strengths = $5
        WHERE submission_id = $6
        RETURNING *
      `;

      const updateParams = [
        data.projectIdea,
        data.projectStage,
        data.fieldOfWork,
        data.fieldOther || null,
        data.projectStrengths,
        data.submissionId,
      ];

      const updateResult = await this.databaseService.query(
        updateQuery,
        updateParams,
      );

      if (updateResult.rowCount === 0) {
        return null;
      }

      // Get complete submission data
      const query = `
        SELECT 
          s.*,
          sd.project_idea,
          sd.project_stage,
          sd.field_of_work,
          sd.field_other,
          sd.project_strengths
        FROM project.submission s
        LEFT JOIN project.submission_detail sd ON s.submission_id = sd.submission_id
        WHERE s.submission_id = $1 AND s.user_id = $2
      `;

      const fetchResult = await this.databaseService.query(query, [
        data.submissionId,
        userId,
      ]);

      if (fetchResult.rowCount === 0) {
        return null;
      }

      return ProjectMapper.fromDatabase(fetchResult.rows[0]);
    } catch (error) {
      console.log(error);
      throw new ProjectInitiationFailedException();
    }
  }

  async updateProductInfo(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null> {
    try {
      // Check if submission exists and belongs to user
      const checkQuery = `
        SELECT submission_id FROM project.submission
        WHERE submission_id = $1 AND user_id = $2
      `;
      const checkResult = await this.databaseService.query(checkQuery, [
        data.submissionId,
        userId,
      ]);

      if (checkResult.rowCount === 0) {
        throw new Error('Submission not found or unauthorized');
      }

      // Update product info fields
      const updateQuery = `
        UPDATE project.submission_detail
        SET
          main_product = $1,
          similar_products = $2,
          product_need = $3,
          target_customers = $4,
          update_stages = $5,
          selling_method = $6,
          innovation = $7
        WHERE submission_id = $8
        RETURNING *
      `;

      const updateParams = [
        data.mainProduct,
        data.similarProducts || null,
        data.productNeed,
        data.targetCustomers,
        data.updateStages || null,
        data.sellingMethod,
        data.innovation,
        data.submissionId,
      ];

      const updateResult = await this.databaseService.query(
        updateQuery,
        updateParams,
      );

      if (updateResult.rowCount === 0) {
        return null;
      }

      // Get complete submission data with product info
      const query = `
        SELECT 
          s.*,
          sd.project_idea,
          sd.project_stage,
          sd.field_of_work,
          sd.field_other,
          sd.project_strengths,
          sd.main_product,
          sd.similar_products,
          sd.product_need,
          sd.target_customers,
          sd.update_stages,
          sd.selling_method,
          sd.innovation
        FROM project.submission s
        LEFT JOIN project.submission_detail sd ON s.submission_id = sd.submission_id
        WHERE s.submission_id = $1 AND s.user_id = $2
      `;

      const fetchResult = await this.databaseService.query(query, [
        data.submissionId,
        userId,
      ]);

      if (fetchResult.rowCount === 0) {
        return null;
      }

      return ProductInfoMapper.fromDatabase(fetchResult.rows[0]);
    } catch (error) {
      throw new ProductInfoUpdateFailedException();
    }
  }

  async updateMarketInfo(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null> {
    try {
      // Check if submission exists and belongs to user
      const checkQuery = `
        SELECT submission_id FROM project.submission
        WHERE submission_id = $1 AND user_id = $2
      `;
      const checkResult = await this.databaseService.query(checkQuery, [
        data.submissionId,
        userId,
      ]);

      if (checkResult.rowCount === 0) {
        throw new Error('Submission not found or unauthorized');
      }

      // Update market info fields
      const updateQuery = `
        UPDATE project.submission_detail
        SET
          market_ready_date = $1,
          market_needs = $2,
          other_products = $3,
          market_scope = $4,
          expected_customers = $5
        WHERE submission_id = $6
        RETURNING *
      `;

      const updateParams = [
        data.marketReadyDate || null,
        data.marketNeeds,
        data.otherProducts || null,
        data.marketScope,
        data.expectedCustomers,
        data.submissionId,
      ];

      const updateResult = await this.databaseService.query(
        updateQuery,
        updateParams,
      );

      if (updateResult.rowCount === 0) {
        return null;
      }

      // Get complete submission data with market info
      const query = `
        SELECT 
          s.*,
          sd.project_idea,
          sd.project_stage,
          sd.field_of_work,
          sd.field_other,
          sd.project_strengths,
          sd.main_product,
          sd.similar_products,
          sd.product_need,
          sd.target_customers,
          sd.update_stages,
          sd.selling_method,
          sd.innovation,
          sd.market_ready_date,
          sd.market_needs,
          sd.expected_customers,
          sd.other_products,
          sd.market_scope
        FROM project.submission s
        LEFT JOIN project.submission_detail sd ON s.submission_id = sd.submission_id
        WHERE s.submission_id = $1 AND s.user_id = $2
      `;

      const fetchResult = await this.databaseService.query(query, [
        data.submissionId,
        userId,
      ]);

      if (fetchResult.rowCount === 0) {
        return null;
      }

      return MarketMapper.fromDatabase(fetchResult.rows[0]);
    } catch (error) {
      throw new MarketInfoUpdateFailedException();
    }
  }

  async updateIncubatorRoleInfo(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null> {
    try {
      // Check if submission exists and belongs to user
      const checkQuery = `
        SELECT submission_id FROM project.submission
        WHERE submission_id = $1 AND user_id = $2
      `;
      const checkResult = await this.databaseService.query(checkQuery, [
        data.submissionId,
        userId,
      ]);

      if (checkResult.rowCount === 0) {
        throw new Error('Submission not found or unauthorized');
      }

      // Update incubator role info fields
      const updateQuery = `
        UPDATE project.submission_detail
        SET
          incubator_benefits = $1,
          project_requirements = $2
        WHERE submission_id = $3
        RETURNING *
      `;

      const updateParams = [
        data.incubatorBenefits,
        data.projectRequirements,
        data.submissionId,
      ];

      const updateResult = await this.databaseService.query(
        updateQuery,
        updateParams,
      );

      if (updateResult.rowCount === 0) {
        return null;
      }

      // Get complete submission data with incubator role info
      const query = `
        SELECT 
          s.*,
          sd.project_idea,
          sd.project_stage,
          sd.field_of_work,
          sd.field_other,
          sd.project_strengths,
          sd.main_product,
          sd.similar_products,
          sd.product_need,
          sd.target_customers,
          sd.update_stages,
          sd.selling_method,
          sd.innovation,
          sd.market_ready_date,
          sd.market_needs,
          sd.other_products,
          sd.market_scope,
          sd.incubator_benefits,
          sd.project_requirements
        FROM project.submission s
        LEFT JOIN project.submission_detail sd ON s.submission_id = sd.submission_id
        WHERE s.submission_id = $1 AND s.user_id = $2
      `;

      const fetchResult = await this.databaseService.query(query, [
        data.submissionId,
        userId,
      ]);

      if (fetchResult.rowCount === 0) {
        return null;
      }

      return IncubatorRoleMapper.fromDatabase(fetchResult.rows[0]);
    } catch (error) {
      throw new IncubatorRoleUpdateFailedException();
    }
  }

  async updateTimelineFinanceInfo(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null> {
    try {
      // Check if submission exists and belongs to user
      const checkQuery = `
        SELECT submission_id FROM project.submission
        WHERE submission_id = $1 AND user_id = $2
      `;
      const checkResult = await this.databaseService.query(checkQuery, [
        data.submissionId,
        userId,
      ]);

      if (checkResult.rowCount === 0) {
        throw new Error('Submission not found or unauthorized');
      }

      // Update timeline & finance info fields
      const updateQuery = `
        UPDATE project.submission_detail
        SET
          phase_1_desc = $1,
          phase_1_duration = $2,
          phase_2_desc = $3,
          phase_2_duration = $4,
          phase_3_desc = $5,
          phase_3_duration = $6,
          phase_4_desc = $7,
          phase_4_duration = $8,
          sales_increase_6mo = $9,
          sales_increase_12mo = $10,
          sales_increase_24mo = $11,
          estimated_investment_cost = $12,
          estimated_funding_needed = $13,
          funding_sources = $14
        WHERE submission_id = $15
        RETURNING *
      `;

      const updateParams = [
        data.phase1Desc,
        data.phase1Duration,
        data.phase2Desc,
        data.phase2Duration,
        data.phase3Desc,
        data.phase3Duration,
        data.phase4Desc,
        data.phase4Duration,
        data.salesIncrease6mo,
        data.salesIncrease12mo,
        data.salesIncrease24mo,
        data.estimatedInvestmentCost,
        data.estimatedFundingNeeded,
        data.fundingSources,
        data.submissionId,
      ];

      const updateResult = await this.databaseService.query(
        updateQuery,
        updateParams,
      );

      if (updateResult.rowCount === 0) {
        return null;
      }

      // Get complete submission data with timeline & finance info
      const query = `
        SELECT 
          s.*,
          sd.project_idea,
          sd.project_stage,
          sd.field_of_work,
          sd.field_other,
          sd.project_strengths,
          sd.main_product,
          sd.similar_products,
          sd.product_need,
          sd.target_customers,
          sd.update_stages,
          sd.selling_method,
          sd.innovation,
          sd.market_ready_date,
          sd.market_needs,
          sd.other_products,
          sd.market_scope,
          sd.incubator_benefits,
          sd.project_requirements,
          sd.phase_1_desc,
          sd.phase_1_duration,
          sd.phase_2_desc,
          sd.phase_2_duration,
          sd.phase_3_desc,
          sd.phase_3_duration,
          sd.phase_4_desc,
          sd.phase_4_duration,
          sd.sales_increase_6mo,
          sd.sales_increase_12mo,
          sd.sales_increase_24mo,
          sd.estimated_investment_cost,
          sd.estimated_funding_needed,
          sd.funding_sources
        FROM project.submission s
        LEFT JOIN project.submission_detail sd ON s.submission_id = sd.submission_id
        WHERE s.submission_id = $1 AND s.user_id = $2
      `;

      const fetchResult = await this.databaseService.query(query, [
        data.submissionId,
        userId,
      ]);

      if (fetchResult.rowCount === 0) {
        return null;
      }

      return TimelineFinanceMapper.fromDatabase(fetchResult.rows[0]);
    } catch (error) {
      throw new TimelineFinanceUpdateFailedException();
    }
  }

  async updateProjectWorkInfo(
    userId: number,
    data: ProjectSubmissionEntity,
  ): Promise<ProjectSubmissionEntity | null> {
    try {
      // Check if submission exists and belongs to user
      const checkQuery = `
        SELECT submission_id FROM project.submission
        WHERE submission_id = $1 AND user_id = $2
      `;
      const checkResult = await this.databaseService.query(checkQuery, [
        data.submissionId,
        userId,
      ]);

      if (checkResult.rowCount === 0) {
        throw new Error('Submission not found or unauthorized');
      }

      // Update project work info fields
      const updateQuery = `
        UPDATE project.submission_detail
        SET
          ownership_structure = $1,
          daily_management = $2,
          employee_count = $3,
          needed_skills = $4,
          activity_nature = $5
        WHERE submission_id = $6
        RETURNING *
      `;

      const updateParams = [
        data.ownershipStructure,
        data.dailyManagement,
        data.employeeCount,
        data.neededSkills,
        data.activityNature,
        data.submissionId,
      ];

      const updateResult = await this.databaseService.query(
        updateQuery,
        updateParams,
      );

      if (updateResult.rowCount === 0) {
        return null;
      }

      // Get complete submission data with project work info
      const query = `
        SELECT 
          s.*,
          sd.project_idea,
          sd.project_stage,
          sd.field_of_work,
          sd.field_other,
          sd.project_strengths,
          sd.main_product,
          sd.similar_products,
          sd.product_need,
          sd.target_customers,
          sd.update_stages,
          sd.selling_method,
          sd.innovation,
          sd.market_ready_date,
          sd.market_needs,
          sd.other_products,
          sd.market_scope,
          sd.incubator_benefits,
          sd.project_requirements,
          sd.phase_1_desc,
          sd.phase_1_duration,
          sd.phase_2_desc,
          sd.phase_2_duration,
          sd.phase_3_desc,
          sd.phase_3_duration,
          sd.phase_4_desc,
          sd.phase_4_duration,
          sd.sales_increase_6mo,
          sd.sales_increase_12mo,
          sd.sales_increase_24mo,
          sd.estimated_investment_cost,
          sd.estimated_funding_needed,
          sd.funding_sources,
          sd.ownership_structure,
          sd.daily_management,
          sd.employee_count,
          sd.needed_skills,
          sd.activity_nature
        FROM project.submission s
        LEFT JOIN project.submission_detail sd ON s.submission_id = sd.submission_id
        WHERE s.submission_id = $1 AND s.user_id = $2
      `;

      const fetchResult = await this.databaseService.query(query, [
        data.submissionId,
        userId,
      ]);

      if (fetchResult.rowCount === 0) {
        return null;
      }

      return ProjectWorkMapper.fromDatabase(fetchResult.rows[0]);
    } catch (error) {
      throw new ProjectWorkUpdateFailedException();
    }
  }
}
